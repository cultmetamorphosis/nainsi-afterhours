# Piyush × Nainsi — Afterhours V8

A mobile-first, 13-scene romantic game story made for Nainsi by Piyush.

## Open it

For the smoothest experience, use the hosted HTTPS link in Chrome. The first real tap starts the bundled soundtrack and requests fullscreen because mobile browsers do not permit either one before a user gesture.

For a local check, extract the ZIP first and open `index.html`. Do not open `index.html` while it is still inside the ZIP. Fullscreen, installability, service-worker caching, and reload behavior are most reliable over HTTPS.

## Publish free with GitHub Pages

1. Create a new GitHub repository, for example `nainsi-afterhours`.
2. Upload **the contents of this folder** to the repository root (so `index.html` is at the top level).
3. Open **Settings → Pages** in the repository.
4. Under **Build and deployment → Source**, choose **GitHub Actions**.
5. Push to `main`, or open **Actions → Deploy P × N Afterhours → Run workflow**.
6. The site will appear at `https://YOUR-USERNAME.github.io/nainsi-afterhours/`.

The included workflow deploys automatically. Hash-based chapters such as `#kisses` mean a normal refresh does not download `index.html` or lose the current chapter when hosted.

## What is included

- One compulsory first-tap immersive gate for music and fullscreen
- Original 107-second, 256 kbps romantic MP3 score (offline and loopable)
- 16 locally bundled interaction SFX
- Local fallback fonts plus online enhanced cute fonts
- 13 scenes with nine interactive games
- Haptic patterns where Android Chrome exposes the Vibration API
- GSAP/ScrollTrigger enhancement with native animation fallbacks
- Proposal button that runs five times, confetti finale, and Panda–Teddy walkout
- PWA manifest, service worker, GitHub Pages action, and 404 fallback

## Browser notes

- Chrome requires a real user tap before audio or fullscreen can begin. The opening gate supplies that tap and will not dismiss until both requests succeed.
- Haptics depend on the phone/browser. Android Chrome commonly supports `navigator.vibrate`; some devices, Battery Saver modes, and iPhones may ignore it.
- The music and effects controls remain available in the top bar after entering.

The soundtrack and sound effects in this package are original generated assets. No commercial recording or copyrighted song lyrics are redistributed.

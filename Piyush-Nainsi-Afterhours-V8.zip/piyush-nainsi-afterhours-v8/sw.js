const CACHE = "piyush-nainsi-afterhours-v8.0.0";
const CORE = [
  "./",
  "./index.html",
  "./styles.css",
  "./app.js",
  "./manifest.webmanifest",
  "./icon.svg",
  "./assets/fonts/BubuBubble.woff",
  "./assets/fonts/CutieRound.woff",
  "./assets/fonts/LoveNote.woff",
  "./assets/audio/moonlit-us.mp3",
  "./assets/audio/tap.mp3",
  "./assets/audio/pop.mp3",
  "./assets/audio/sparkle.mp3",
  "./assets/audio/correct.mp3",
  "./assets/audio/wrong.mp3",
  "./assets/audio/kiss.mp3",
  "./assets/audio/page-whoosh.mp3",
  "./assets/audio/car.mp3",
  "./assets/audio/piano.mp3",
  "./assets/audio/guitar.mp3",
  "./assets/audio/heartbeat.mp3",
  "./assets/audio/cup.mp3",
  "./assets/audio/drum.mp3",
  "./assets/audio/camera.mp3",
  "./assets/audio/finale.mp3",
  "./assets/audio/chime.mp3"
];

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(CORE)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((key) => key !== CACHE).map((key) => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) return;

  if (event.request.mode === "navigate") {
    event.respondWith(
      fetch(event.request)
        .then((response) => {
          const copy = response.clone();
          caches.open(CACHE).then((cache) => cache.put("./index.html", copy));
          return response;
        })
        .catch(() => caches.match("./index.html"))
    );
    return;
  }

  event.respondWith(
    caches.match(event.request).then((cached) => cached || fetch(event.request).then((response) => {
      if (response.ok) caches.open(CACHE).then((cache) => cache.put(event.request, response.clone()));
      return response;
    }))
  );
});

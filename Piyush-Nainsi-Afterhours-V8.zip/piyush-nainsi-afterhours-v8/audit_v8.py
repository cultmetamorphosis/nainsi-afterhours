#!/usr/bin/env python3
"""Static and media integrity audit for the complete V8 package."""

from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path
from urllib.parse import urlparse

from lxml import html


ROOT = Path(__file__).resolve().parent
HTML = (ROOT / "index.html").read_text(encoding="utf-8")
JS = (ROOT / "app.js").read_text(encoding="utf-8")
CSS = (ROOT / "styles.css").read_text(encoding="utf-8")
DOC = html.fromstring(HTML)
CHECKS: list[str] = []


def check(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)
    CHECKS.append(message)


ids = DOC.xpath("//*[@id]/@id")
check(len(ids) == len(set(ids)), "HTML IDs are unique")

js_ids = set(re.findall(r'\$\("#([A-Za-z][\w-]*)"\)', JS))
missing_ids = sorted(js_ids - set(ids))
check(not missing_ids, f"all {len(js_ids)} direct JS ID references exist")

scenes = DOC.xpath('//*[@data-scene]/@data-scene')
check(len(scenes) == 13, "13 story scenes are present")
match = re.search(r'const sceneOrder = \[([^;]+)\];', JS)
scene_order = re.findall(r'"([^"]+)"', match.group(1)) if match else []
check(scene_order == scenes, "scene routing order matches the DOM")

go_targets = DOC.xpath('//*[@data-go]/@data-go')
check(not (set(go_targets) - set(scenes)), "every CTA routes to a real scene")
check(len(go_targets) >= 10 and 'goTo("snacks")' in JS and 'goTo("stars")' in JS, "all 12 chapter advances are wired")

check(len(DOC.xpath('//*[@data-memory]')) == 4, "memory hunt has 4 interactive clues")
check(len(DOC.xpath('//*[@data-decoder]')) == 3 and "decoderCases" in JS, "language decoder is interactive")
check(len(DOC.xpath('//*[@data-mood]')) == 4, "mood laboratory has 4 choices")
check("spawnSnack" in JS and "state.snacks >= 6" in JS, "falling-snack game requires 6 catches")
check(len(DOC.xpath('//*[@data-pad]')) == 4 and "rhythmPattern" in JS, "Jaguar rhythm game is wired")
check(len(DOC.xpath('//*[@data-answer]')) == 3 and "quizQuestions" in JS, "relationship quiz is wired")
check(len(DOC.xpath('//*[@data-status-bg]')) == 3 and len(DOC.xpath('//*[@data-status-line]')) == 3, "status maker controls are wired")
check("duration = 1200" in JS and "holdFallbackTaps < 3" in JS, "long-press game has a 3-tap fallback")
check("state.kisses >= 5" in JS and "Math.max(360, 570 - state.kisses * 38)" in JS, "moving kiss requires 5 catches")
check(len(DOC.xpath('//*[@data-star]')) == 5, "promise constellation has 5 stars")
check("proposalRuns < 5" in JS and "acceptProposal();" in JS, "proposal runs 5 times and accepts on click 6")
check("walkout-duo" in HTML and "🐼" in HTML and "🧸" in HTML and "🤝" in HTML, "Panda and Teddy hold hands for the walkout")

whatsapp = "https://wa.me/+917004804153"
check(HTML.count(whatsapp) >= 2 and whatsapp in JS, "all final WhatsApp actions use the requested number")

check('id="immersive-gate"' in HTML and 'id="music-check"' in HTML and 'id="fullscreen-check"' in HTML, "compulsory immersive gate includes music and fullscreen")
check("fullscreenReady && musicReady" in JS, "gate unlocks only after both immersive requests succeed")
check("requestFullscreen" in JS and "this.music.play()" in JS, "fullscreen and audio start from the opening gesture")
check("music picker" not in HTML.lower() and 'type="file"' not in HTML.lower(), "there is no music picker or chooser")

manifest = json.loads((ROOT / "manifest.webmanifest").read_text(encoding="utf-8"))
check(manifest.get("display") == "fullscreen", "PWA manifest requests fullscreen display")
check(manifest.get("start_url") == "./#home", "PWA start URL uses stable hash routing")
check("location.hash" in JS and "history.pushState" in JS, "chapters use reload-safe hash routing")
check((ROOT / "404.html").exists() and (ROOT / ".nojekyll").exists(), "GitHub Pages reload fallbacks are present")
check((ROOT / ".github/workflows/deploy-pages.yml").exists(), "GitHub Pages deploy workflow is included")
check("serviceWorker.register" in JS and (ROOT / "sw.js").exists(), "offline service worker is registered on HTTPS")

for element in DOC.xpath('//*[@src or @href]'):
    value = element.get("src") or element.get("href") or ""
    parsed = urlparse(value)
    if parsed.scheme or value.startswith("#") or value.startswith("data:"):
        continue
    local = value.split("?", 1)[0].split("#", 1)[0]
    if local:
        check((ROOT / local).exists(), f"local asset exists: {local}")

check(CSS.count("{") == CSS.count("}"), "CSS braces are balanced")
check("@font-face" in CSS and len(list((ROOT / "assets/fonts").glob("*.woff"))) == 3, "three offline fallback fonts are bundled")
check("prefers-reduced-motion" in CSS, "reduced-motion accessibility is covered")
check("pointer-events:none" in CSS.replace(" ", ""), "decorative overlays cannot steal taps")

audio_files = sorted((ROOT / "assets/audio").glob("*.mp3"))
check(len(audio_files) == 17, "17 bundled MP3 assets are present")
for audio in audio_files:
    process = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration,bit_rate", "-of", "json", str(audio)],
        check=True,
        capture_output=True,
        text=True,
    )
    metadata = json.loads(process.stdout)["format"]
    check(float(metadata["duration"]) > 0.15, f"audio decodes: {audio.name}")
    check(int(metadata["bit_rate"]) >= 180_000, f"audio bitrate is high quality: {audio.name}")

music = ROOT / "assets/audio/moonlit-us.mp3"
metadata = json.loads(subprocess.run(
    ["ffprobe", "-v", "error", "-show_entries", "format=duration,bit_rate", "-of", "json", str(music)],
    check=True,
    capture_output=True,
    text=True,
).stdout)["format"]
check(float(metadata["duration"]) > 100, "background score is longer than 100 seconds")
check(int(metadata["bit_rate"]) >= 250_000, "background score is at least 250 kbps")

subprocess.run(["node", "--check", str(ROOT / "app.js")], check=True, capture_output=True, text=True)
check(True, "JavaScript passes Node syntax validation")

print(f"V8 audit passed: {len(CHECKS)} checks")
for item in CHECKS:
    print(f"  ✓ {item}")

#!/usr/bin/env python3
"""Generate the original offline soundtrack and tactile SFX for V8."""

from __future__ import annotations

import math
import subprocess
import tempfile
from pathlib import Path

import numpy as np
from scipy.io import wavfile


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "assets" / "audio"
SR = 44_100
RNG = np.random.default_rng(1102)


def midi(note: float) -> float:
    return 440.0 * 2.0 ** ((note - 69.0) / 12.0)


def envelope(size: int, attack: float, release: float, curve: float = 1.0) -> np.ndarray:
    env = np.ones(size, dtype=np.float32)
    a = min(size, max(1, int(attack * SR)))
    r = min(size, max(1, int(release * SR)))
    env[:a] = np.linspace(0.0, 1.0, a, dtype=np.float32) ** curve
    env[-r:] *= np.linspace(1.0, 0.0, r, dtype=np.float32) ** curve
    return env


def oscillator(freq: float, size: int, kind: str = "warm", phase: float = 0.0) -> np.ndarray:
    t = np.arange(size, dtype=np.float32) / SR
    angle = 2.0 * np.pi * freq * t + phase
    if kind == "sine":
        return np.sin(angle)
    if kind == "bell":
        return (
            np.sin(angle)
            + 0.42 * np.sin(angle * 2.01 + 0.3)
            + 0.21 * np.sin(angle * 3.99 + 0.7)
            + 0.10 * np.sin(angle * 6.02)
        ) / 1.73
    if kind == "guitar":
        return (
            np.sin(angle)
            + 0.34 * np.sin(angle * 2.0 + 0.2)
            + 0.17 * np.sin(angle * 3.0 + 0.8)
            + 0.07 * np.sin(angle * 4.0)
        ) / 1.58
    if kind == "string":
        vibrato = 0.012 * np.sin(2.0 * np.pi * 5.1 * t)
        return (
            np.sin(angle + vibrato)
            + 0.29 * np.sin(angle * 2.0 + 0.5)
            + 0.12 * np.sin(angle * 3.0 + 1.1)
        ) / 1.41
    return (
        np.sin(angle)
        + 0.26 * np.sin(angle * 2.0 + 0.21)
        + 0.10 * np.sin(angle * 3.0 + 0.63)
    ) / 1.36


def add_note(
    mix: np.ndarray,
    start: float,
    duration: float,
    note: float,
    amp: float,
    pan: float = 0.0,
    kind: str = "warm",
    attack: float = 0.02,
    release: float = 0.20,
) -> None:
    left = max(0, int(start * SR))
    size = min(int(duration * SR), mix.shape[0] - left)
    if size <= 0:
        return
    signal = oscillator(midi(note), size, kind, RNG.random() * math.tau)
    signal *= envelope(size, attack, release, 0.72)
    # Equal-power stereo panning.
    angle = (float(np.clip(pan, -1, 1)) + 1.0) * np.pi / 4.0
    mix[left:left + size, 0] += signal * amp * np.cos(angle)
    mix[left:left + size, 1] += signal * amp * np.sin(angle)


def add_noise_hit(mix: np.ndarray, start: float, duration: float, amp: float, pan: float = 0.0) -> None:
    left = int(start * SR)
    size = min(int(duration * SR), mix.shape[0] - left)
    if size <= 0:
        return
    noise = RNG.normal(0, 1, size).astype(np.float32)
    noise = np.convolve(noise, np.ones(7, dtype=np.float32) / 7.0, mode="same")
    noise *= np.exp(-np.linspace(0, 9, size, dtype=np.float32))
    angle = (pan + 1.0) * np.pi / 4.0
    mix[left:left + size, 0] += noise * amp * np.cos(angle)
    mix[left:left + size, 1] += noise * amp * np.sin(angle)


def soften_and_master(mix: np.ndarray, *, reverb: bool = True) -> np.ndarray:
    if reverb:
        dry = mix.copy()
        for delay, gain, cross in [(0.095, 0.17, False), (0.171, 0.12, True), (0.263, 0.08, False), (0.387, 0.055, True)]:
            samples = int(delay * SR)
            if cross:
                mix[samples:, 0] += dry[:-samples, 1] * gain
                mix[samples:, 1] += dry[:-samples, 0] * gain
            else:
                mix[samples:] += dry[:-samples] * gain
    # Gentle low-pass smoothing, then tape-ish saturation.
    for _ in range(2):
        mix[1:] = 0.78 * mix[1:] + 0.22 * mix[:-1]
    mix = np.tanh(mix * 1.24)
    peak = float(np.max(np.abs(mix))) or 1.0
    return (mix / peak * 0.91).astype(np.float32)


def export_mp3(name: str, data: np.ndarray, bitrate: str = "256k") -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    pcm = (np.clip(data, -1, 1) * 32767).astype(np.int16)
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as handle:
        wav_path = Path(handle.name)
    wavfile.write(wav_path, SR, pcm)
    try:
        subprocess.run(
            [
                "ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(wav_path),
                "-codec:a", "libmp3lame", "-b:a", bitrate, "-ar", str(SR), "-ac", "2", str(OUT / name),
            ],
            check=True,
        )
    finally:
        wav_path.unlink(missing_ok=True)


def build_soundtrack() -> None:
    bpm = 72.0
    beat = 60.0 / bpm
    bars = 32
    duration = bars * 4 * beat
    mix = np.zeros((int((duration + 1.2) * SR), 2), dtype=np.float32)

    # D major with add-9 and suspended colours; deliberately original melody.
    chords = [
        [50, 54, 57, 64], [45, 49, 52, 59], [47, 50, 54, 61], [43, 47, 50, 57],
        [50, 54, 57, 64], [45, 49, 52, 57], [42, 47, 50, 57], [43, 47, 50, 54],
    ]
    melody = [
        66, 69, 71, 69, 66, 64, 66, 69,
        73, 71, 69, 66, 64, 66, 62, 64,
        66, 69, 74, 73, 71, 69, 66, 64,
        62, 64, 66, 69, 67, 66, 64, 62,
    ]

    for bar in range(bars):
        start = bar * 4 * beat
        chord = chords[bar % len(chords)]
        section = bar // 8
        section_gain = [0.62, 0.86, 1.0, 0.79][section]
        if bar == 0:
            section_gain *= 0.72

        # Lush held strings arrive gradually.
        if bar >= 4:
            for idx, note in enumerate(chord[1:]):
                add_note(mix, start, 4.15 * beat, note + 12, 0.025 * section_gain, (-0.62, 0.1, 0.59)[idx], "string", 0.55, 0.85)

        # Warm piano eighth-note arpeggio.
        arp = [0, 1, 2, 3, 2, 1, 3, 1]
        for step, chord_index in enumerate(arp):
            velocity = (1.0 if step in (0, 4) else 0.72) * section_gain
            note = chord[chord_index] + (12 if chord_index > 0 else 0)
            add_note(mix, start + step * beat / 2, beat * 0.78, note, 0.085 * velocity, -0.25 + 0.08 * chord_index, "warm", 0.009, 0.31)

        # Soft acoustic-guitar brush on offbeats.
        if bar >= 2:
            for pulse in (0.0, 1.5, 2.0, 3.5):
                for idx, note in enumerate(chord[1:]):
                    add_note(mix, start + (pulse + idx * 0.028) * beat, 0.82 * beat, note + 12, 0.027 * section_gain, 0.38 + idx * 0.11, "guitar", 0.005, 0.48)

        # Rounded bass anchors the middle and final sections.
        if bar >= 6:
            add_note(mix, start, 1.75 * beat, chord[0] - 12, 0.074 * section_gain, -0.05, "sine", 0.035, 0.44)
            add_note(mix, start + 2 * beat, 1.6 * beat, chord[0] - 12, 0.055 * section_gain, 0.03, "sine", 0.035, 0.40)

        # A distinct, non-derivative music-box melody.
        if 4 <= bar < 30:
            notes = melody[(bar * 2) % len(melody):(bar * 2) % len(melody) + 2]
            if len(notes) < 2:
                notes += melody[:2 - len(notes)]
            add_note(mix, start + 0.5 * beat, 1.12 * beat, notes[0], 0.064 * section_gain, 0.24, "bell", 0.008, 0.56)
            add_note(mix, start + 2.5 * beat, 1.18 * beat, notes[1], 0.058 * section_gain, -0.18, "bell", 0.008, 0.58)

        # Brushed, heartbeat-like rhythm; intimate rather than clubby.
        if 8 <= bar < 29:
            for pulse in (0, 2):
                kick_t = start + pulse * beat
                length = int(0.24 * SR)
                t = np.arange(length, dtype=np.float32) / SR
                kick = np.sin(2 * np.pi * (74 - 33 * t) * t) * np.exp(-t * 17) * 0.12
                base = int(kick_t * SR)
                mix[base:base + length, 0] += kick
                mix[base:base + length, 1] += kick
            for pulse in (1, 3):
                add_noise_hit(mix, start + pulse * beat, 0.19, 0.026, 0.15)
            for eighth in range(8):
                add_noise_hit(mix, start + eighth * beat / 2, 0.07, 0.010, -0.48 if eighth % 2 else 0.48)

    # Intro swell and natural outro.
    mastered = soften_and_master(mix)
    fade_in = int(2.3 * SR)
    fade_out = int(5.2 * SR)
    mastered[:fade_in] *= np.linspace(0, 1, fade_in, dtype=np.float32)[:, None] ** 1.35
    mastered[-fade_out:] *= np.linspace(1, 0, fade_out, dtype=np.float32)[:, None] ** 1.5
    export_mp3("moonlit-us.mp3", mastered, "256k")


def blank(seconds: float) -> np.ndarray:
    return np.zeros((int(seconds * SR), 2), dtype=np.float32)


def stereo_note(seconds: float, notes: list[tuple[float, float, float, str, float]]) -> np.ndarray:
    mix = blank(seconds)
    for start, duration, note, kind, amp in notes:
        add_note(mix, start, duration, note, amp, RNG.uniform(-0.22, 0.22), kind, 0.005, min(0.34, duration * 0.55))
    return soften_and_master(mix, reverb=True)


def build_sfx() -> None:
    effects: dict[str, np.ndarray] = {}
    effects["tap.mp3"] = stereo_note(0.19, [(0, .15, 84, "bell", .35)])
    effects["pop.mp3"] = stereo_note(.34, [(0, .18, 72, "sine", .38), (.07, .2, 84, "bell", .23)])
    effects["sparkle.mp3"] = stereo_note(.88, [(0, .48, 79, "bell", .24), (.1, .52, 83, "bell", .22), (.21, .56, 88, "bell", .19), (.34, .5, 91, "bell", .15)])
    effects["correct.mp3"] = stereo_note(1.12, [(0, .55, 74, "warm", .28), (.16, .66, 78, "warm", .25), (.33, .72, 81, "bell", .27), (.52, .55, 86, "bell", .17)])
    effects["wrong.mp3"] = stereo_note(.46, [(0, .22, 52, "warm", .30), (.18, .24, 49, "warm", .25)])
    effects["kiss.mp3"] = stereo_note(.56, [(0, .18, 76, "sine", .28), (.11, .39, 88, "bell", .26)])
    effects["car.mp3"] = stereo_note(1.16, [(0, 1.02, 38, "warm", .28), (.18, .9, 45, "guitar", .14), (.62, .46, 62, "bell", .17)])
    effects["piano.mp3"] = stereo_note(1.23, [(0, .98, 69, "warm", .31), (.22, .92, 73, "warm", .27), (.46, .72, 76, "warm", .22)])
    effects["guitar.mp3"] = stereo_note(1.03, [(0, .86, 62, "guitar", .31), (.035, .82, 69, "guitar", .25), (.07, .78, 74, "guitar", .22)])
    effects["heartbeat.mp3"] = stereo_note(.63, [(0, .25, 45, "sine", .40), (.26, .26, 43, "sine", .32)])
    effects["cup.mp3"] = stereo_note(.74, [(0, .34, 82, "bell", .24), (.09, .51, 90, "bell", .19)])
    effects["drum.mp3"] = stereo_note(.40, [(0, .31, 43, "sine", .44)])
    effects["camera.mp3"] = stereo_note(.43, [(0, .12, 91, "bell", .34), (.08, .29, 79, "warm", .22)])
    effects["chime.mp3"] = stereo_note(1.42, [(0, .88, 78, "bell", .25), (.18, 1.0, 83, "bell", .22), (.39, .98, 90, "bell", .18)])
    effects["finale.mp3"] = stereo_note(3.35, [(0, 2.5, 62, "string", .20), (.06, 2.4, 69, "string", .17), (.14, 2.35, 74, "string", .17), (.32, 1.4, 78, "bell", .23), (.78, 1.8, 81, "bell", .22), (1.27, 1.8, 86, "bell", .19)])

    whoosh = blank(.82)
    size = whoosh.shape[0]
    noise = RNG.normal(0, 1, size).astype(np.float32)
    smooth = np.convolve(noise, np.ones(35, dtype=np.float32) / 35.0, mode="same")
    env = np.clip(np.sin(np.linspace(0, np.pi, size, dtype=np.float32)), 0, 1) ** 1.7
    sweep = smooth * env * np.linspace(.18, .58, size, dtype=np.float32)
    whoosh[:, 0] = sweep
    whoosh[:, 1] = sweep[::-1]
    effects["page-whoosh.mp3"] = soften_and_master(whoosh, reverb=False)

    for name, audio in effects.items():
        export_mp3(name, audio, "192k")


if __name__ == "__main__":
    build_soundtrack()
    build_sfx()
    print(f"Generated {len(list(OUT.glob('*.mp3')))} MP3 assets in {OUT}")

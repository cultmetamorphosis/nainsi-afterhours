(() => {
  "use strict";

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const sceneOrder = ["home", "origin", "memory", "scold", "belan", "mood", "snacks", "jaguar", "quiz", "status", "tetris", "balloons", "sleep", "secret", "kisses", "plan", "stars", "final"];
  const storageKey = "piyush-nainsi-v10-story-state";
  const scenes = new Map($$("[data-scene]").map((scene) => [scene.dataset.scene, scene]));
  const hasGsap = Boolean(window.gsap);
  const hasScrollTrigger = Boolean(window.gsap && window.ScrollTrigger);
  const sceneModes = {
    home: "start", origin: "origin", memory: "discover", scold: "decode", belan: "dodge",
    mood: "choose", snacks: "catch", jaguar: "rhythm", quiz: "know", status: "create",
    tetris: "build", balloons: "aim", sleep: "feel", secret: "hold", kisses: "chase",
    plan: "plan", stars: "promise", final: "forever"
  };

  const state = {
    photoFocused: false, photoMoments: [], memories: [], decoderRound: 0, belanDodges: 0,
    moods: [], nakhra: 42, snacks: 0, rhythmStep: 0, quizRound: 0,
    statusBg: "", statusLine: "", statusSticker: "", tetrisLines: 0, balloons: [], dreams: [],
    secret: false, kisses: 0, plan: "", planEmoji: "🎁", date: "", time: "", stars: [], soundOn: true
  };

  const photoLines = [
    "Us waqt hum camera ke saamne bas thode awkward the. Mujhe nahi pata tha—ye awkward beginning meri favourite memory banegi.",
    "Is frame mein koi grand promise nahi tha. Bas do log the… aur ek story jo chup-chaap start ho rahi thi.",
    "Aaj is photo ko dekhta hoon toh faces se zyada woh second dikhta hai jahan ‘main’ ke paas quietly ‘tum’ aa gayi."
  ];

  const memoryLines = [
    { emoji: "😤", panda: "panda thoda darr gaya", copy: "Tumhara ‘Maar Denge’ sunke main seedha kam, smile zyada karta hoon. Survival instinct thoda questionable hai." },
    { emoji: "📞", panda: "call abhi nahi kategi", copy: "Tum ‘Phone Kaaten?’ bolti ho—and suddenly mere paas seventeen aur important baatein aa jaati hain." },
    { emoji: "🥺", panda: "strict Dudu left the chat", copy: "‘Dudu… daantoge nahi naa?’ Ye unfair move hai, Chhutku Baby. Uske baad main kya hi daantun." },
    { emoji: "🎁", panda: "evidence secured", copy: "Tumhare romantic statuses aur surprise boxes mein gift se zyada tumhara effort mujhe hit karta hai. Main sab notice karta hoon." }
  ];

  const decoderCases = [
    { prompt: "“Maar Denge”", options: ["Okay bye", "Pehle paas toh aao 😌", "Main busy hoon"], correct: 1, line: "Correct. Threat received as premium affection." },
    { prompt: "“Phone Kaaten?”", options: ["Haan kaat do", "Network gaya", "Kaat ke dikhao, call back aa jayega"], correct: 2, line: "Exactly. Dudu ke paas unlimited callback energy hai." },
    { prompt: "“Dudu!!! Daantoge nahi naa?”", options: ["Nahi Chhutku, idhar aao", "Pehle confession", "Seen 11:47 PM"], correct: 0, line: "Daantna cancelled. Cuteness ne legal stay le liya." },
    { prompt: "“Randi”", options: ["Excuse me?", "Haan ji, tumhara premium version", "Customer care call karo"], correct: 1, line: "Certified Nainsi dialect. Panda approves reluctantly." }
  ];

  const quizQuestions = [
    { question: "Piyush ka mood sabse fast kaun theek karta hai?", options: ["Good food", "Nainsi ki Aawaaz", "Obviously both"], correct: 1, line: "Tumhari aawaaz. Bas. Food ko is round mein participation certificate milega." },
    { question: "Tum romantic WhatsApp status lagao toh Dudu kya karta hai?", options: ["Cool act", "Baar-baar dekhta", "Notice hi nahi"], correct: 1, line: "Baar-baar dekhta hoon. Cool act har baar fail." },
    { question: "Tumhare surprise box ka best part?", options: ["Gift", "Ribbon", "Tumhara effort"], correct: 2, line: "Tumhara effort. Gift khatam ho sakta hai; woh feeling nahi." },
    { question: "Dream Jaguar ki aux officially kiski?", options: ["Piyush", "Nainsi", "Panda DJ"], correct: 1, line: "Nainsi ki. Tum gaogi; main embarrassingly proud audience." }
  ];

  const rhythmPattern = [0, 1, 2, 3, 1, 0];
  const rhythmLines = ["beat pakda 🎯", "riff locked 🎸", "sparkle approved ✨", "heart engine on 💗", "BuBu on vocals 🎤", "Jaguar unlocked 🏎️"];
  const starLines = [
    "Main tumhari baat properly sunna choose karta hoon.",
    "Tumhare effort ko kabhi ‘small’ nahi bolunga.",
    "Messy days mein thoda extra patience rakhunga.",
    "Jo feel karunga, honestly bolne ki koshish karunga.",
    "Aur har version mein—main tumhe choose karta hoon."
  ];
  const kissTaunts = [
    "Nahi, itni aasaani se kaise? 😏", "Reflexes dangerous hain, BuBu 👀",
    "Panda ne side badal di—complain usse karo 🐼", "Almost overconfident, Chhutku 😌",
    "Fine. Five out of five. Saare tumhare 💗"
  ];

  const balloonSecrets = [
    "Secret 01: Tumhari scolding ke baad bhi main screen dekh ke smile karta hoon. Self-respect thodi flexible hai.",
    "Secret 02: Humari first photo mere liye photo nahi—woh exact jagah hai jahan future thoda less blurry laga.",
    "Secret 03: Tum so rahi hoti ho toh tumhare tiny expressions ka pura silent cinema chalta hai. Main happily audience hoon.",
    "Secret 04: Jaguar se pehle bhi, meri imaginary passenger seat tumhari hi thi. Panda bas temporary driver hai."
  ];

  const dreamLines = [
    "Woh half-smile—jaise sapne mein bhi kisi ko cute sa reply de rahi ho.",
    "Tiny nose scrunch. Do seconds ka scene, mere dimaag mein full replay.",
    "Ek random eyebrow move—and main guess karta rehta hoon sapne mein kiski class lag rahi hai.",
    "Phir tumhari breathing settle hoti hai… aur mujhe bas lagta hai: haan, yahin rehna hai."
  ];

  const transitionRoutes = [
    { ride: "🏎️", cargo: "🍰", text: "Panda ne Jaguar ki keys ‘borrow’ kar li. Teddy ne questions nahi pooche." },
    { ride: "🚀", cargo: "🍫", text: "Chocolate delivery orbit se aa rahi hai. Normal shipping too basic." },
    { ride: "🛸", cargo: "🥘", text: "Sizzler ka smoke dekh ke UFO aa gaya. Fair misunderstanding." },
    { ride: "🛵", cargo: "☕", text: "Coffee safe hai. Pastry ne helmet pehna hai. Mostly safe." },
    { ride: "🦄", cargo: "💍", text: "Wrong vehicle. Correct destination. Nobody panic." }
  ];

  const captionCues = [
    [0, "Us first photo ke baad, duniya thodi zyada tum ho gayi."],
    [13, "Tumhari awaaz aati hai—and mera din apni jagah aa jaata hai."],
    [26, "‘Bapch*da’ plus belan: apparently meri favourite love language."],
    [39, "My Chhutku Baby, tumhara effort mujhe har baar hit karta hai."],
    [52, "Piyush ka favourite notification, favourite voice, favourite person: Nainsi."],
    [65, "Tum so jao. Main thodi der bas tumhare paas reh leta hoon."],
    [78, "Jaguar ki aux tumhari. Har future drive mein seat meri."],
    [91, "Main perfect nahi—par tumhe daily choose karna bilkul clear hai."],
    [104, "Jahan tum ho, wahi mera soft corner permanently saved hai."],
    [117, "Phir se? Haan BuBu. Har version mein tum."]
  ];

  const sfxFiles = {
    tap: "tap.mp3", pop: "pop.mp3", sparkle: "sparkle.mp3", correct: "correct.mp3",
    wrong: "wrong.mp3", kiss: "kiss.mp3", page: "page-whoosh.mp3", car: "car.mp3",
    piano: "piano.mp3", guitar: "guitar.mp3", heart: "heartbeat.mp3", cup: "cup.mp3",
    drum: "drum.mp3", camera: "camera.mp3", finale: "finale.mp3", chime: "chime.mp3",
    belan: "belan.mp3", whoosh: "whoosh-hit.mp3", block: "tetris.mp3", drop: "drop.mp3",
    bow: "bow.mp3", balloon: "balloon.mp3", gift: "gift.mp3", sleep: "sleep-chime.mp3"
  };

  let currentScene = "home";
  let transitionLocked = false;
  let queuedScene = "";
  let toastTimer = 0;
  let snackTimer = 0;
  let snackStarted = false;
  let kissTimer = 0;
  let kissStarted = false;
  let belanTimers = [];
  let belanStarted = false;
  let belanRoundActive = false;
  let belanMovedThisRound = false;
  let belanRoundOrigin = 1;
  let belanLane = 1;
  let duduLane = 1;
  let tetrisTimer = 0;
  let tetrisStarted = false;
  let tetrisLocked = false;
  let tetrisPiece = { row: 0, col: 0, vertical: false };
  let bowStart = null;
  let bowPull = 0;
  let bowShooting = false;
  let bowChargeFrame = 0;
  let bowChargedBuzzed = false;
  let bowFlightAnimation = null;
  let bowFlightTimer = 0;
  let holdFrame = 0;
  let holdPulse = 0;
  let holdStart = 0;
  let holdFallbackTaps = 0;
  let decoderLocked = false;
  let quizLocked = false;
  let proposalRuns = 0;
  let finaleTimers = [];
  let screenshotHandler = null;
  let scrollTweens = [];

  class AudioDirector {
    constructor() {
      this.music = $("#background-music");
      this.enabled = state.soundOn;
      this.started = false;
      this.currentCaption = -1;
      this.restoreTimer = 0;
      this.pools = new Map();
      this.buffers = new Map();
      this.buffersReady = 0;
      this.context = null;
      this.music.volume = .78;
      this.music.addEventListener("timeupdate", () => this.syncCaption());
      this.music.addEventListener("playing", () => updateSoundButton());
      this.music.addEventListener("error", () => setGateStatus("Music file load nahi hui. Page reload karke phir tap karo."));
      this.preloadSfx();
      this.bufferPromise = this.preloadBuffers();
    }

    preloadSfx() {
      Array.from(new Set(Object.values(sfxFiles))).forEach((file) => {
        const tracks = Array.from({ length: 2 }, () => {
          const audio = document.createElement("audio");
          audio.src = "assets/audio/" + file;
          audio.preload = "auto";
          audio.setAttribute("playsinline", "");
          audio.volume = .82;
          audio.load();
          return audio;
        });
        this.pools.set(file, { tracks, cursor: 0 });
      });
    }

    ensureContext() {
      if (this.context) return this.context;
      const Context = window.AudioContext || window.webkitAudioContext;
      if (!Context) return null;
      try { this.context = new Context({ latencyHint: "interactive" }); }
      catch (_) { try { this.context = new Context(); } catch (_) { this.context = null; } }
      return this.context;
    }

    async preloadBuffers() {
      const context = this.ensureContext();
      if (!context) return 0;
      const files = Array.from(new Set(Object.values(sfxFiles)));
      const loaded = await Promise.all(files.map(async (file) => {
        try {
          const response = await fetch("assets/audio/" + file, { cache: "force-cache" });
          if (!response.ok) return false;
          const buffer = await context.decodeAudioData(await response.arrayBuffer());
          this.buffers.set(file, buffer);
          this.buffersReady = this.buffers.size;
          return true;
        } catch (_) { return false; }
      }));
      return loaded.filter(Boolean).length;
    }

    async startConfirmed() {
      this.enabled = true;
      state.soundOn = true;
      try {
        const context = this.ensureContext();
        const resume = context?.resume?.();
        const result = this.music.play();
        const work = [];
        if (resume && typeof resume.then === "function") work.push(resume.catch(() => {}));
        if (result && typeof result.then === "function") work.push(result);
        await Promise.all(work);
        await Promise.race([this.bufferPromise.catch(() => 0), new Promise((resolve) => setTimeout(resolve, 5000))]);
        this.started = true;
        saveState();
        updateSoundButton();
        this.syncCaption();
        return true;
      } catch (_) {
        this.started = false;
        updateSoundButton();
        return false;
      }
    }

    async setEnabled(enabled) {
      this.enabled = Boolean(enabled);
      state.soundOn = this.enabled;
      saveState();
      if (this.enabled) {
        const started = await this.startConfirmed();
        if (started) this.sfx("chime");
        else showToast("Chrome ne music roka. Ek baar phir ♫ tap karo.");
      } else {
        try { this.music.pause(); } catch (_) {}
      }
      updateSoundButton();
    }

    sfx(name = "tap") {
      if (!this.enabled || !this.started) return;
      const file = sfxFiles[name] || sfxFiles.tap;
      const level = name === "tap" ? .62 : (name === "page" ? .72 : .82);
      const buffer = this.buffers.get(file);
      const context = this.context;
      let played = false;
      if (buffer && context && context.state === "running") {
        try {
          const source = context.createBufferSource();
          const gain = context.createGain();
          source.buffer = buffer;
          gain.gain.setValueAtTime(level, context.currentTime);
          source.connect(gain).connect(context.destination);
          source.start(0);
          played = true;
        } catch (_) {}
      }
      if (!played) {
        const pool = this.pools.get(file);
        if (pool) {
          const track = pool.tracks[pool.cursor++ % pool.tracks.length];
          try {
            track.pause();
            track.currentTime = 0;
            track.volume = level;
            const result = track.play();
            if (result && typeof result.catch === "function") result.catch(() => {});
          } catch (_) {}
        }
      }
      if (!this.music.paused) {
        clearTimeout(this.restoreTimer);
        this.music.volume = name === "finale" ? .30 : .44;
        this.restoreTimer = setTimeout(() => { this.music.volume = .78; }, name === "finale" ? 5200 : 760);
      }
    }

    syncCaption() {
      const time = Number.isFinite(this.music.currentTime) ? this.music.currentTime : 0;
      const duration = Number.isFinite(this.music.duration) && this.music.duration > 0 ? this.music.duration : 128;
      let next = 0;
      captionCues.forEach((cue, index) => { if (time >= cue[0]) next = index; });
      if (next !== this.currentCaption) {
        this.currentCaption = next;
        const line = $("#caption-line");
        line.textContent = captionCues[next][1];
        line.animate?.([{ opacity: 0, transform: "translateY(7px)" }, { opacity: 1, transform: "translateY(0)" }], { duration: 420, easing: "ease-out" });
      }
      $("#music-progress").style.width = Math.min(100, time / duration * 100) + "%";
    }

    pauseForVisibility() { if (!this.music.paused) try { this.music.pause(); } catch (_) {} }
    resumeForVisibility() { if (this.enabled && this.started) try { this.music.play()?.catch?.(() => {}); } catch (_) {} }
  }

  class Haptics {
    constructor() {
      this.supported = "vibrate" in navigator && typeof navigator.vibrate === "function";
      this.lastResult = false;
      this.patterns = {
        tap: 42, soft: 55, move: 48, drop: [65, 32, 95], bow: [52, 28, 72],
        heart: [72, 58, 105], emotional: [90, 70, 125, 70, 165],
        success: [55, 45, 80, 52, 135], wrong: [125, 72, 135], bonk: [165, 85, 210],
        hold: 62, calibrate: [120, 95, 170, 105, 230]
      };
    }
    prime() {
      return this.pulse("calibrate");
    }
    pulse(kind = "tap") {
      const pattern = Array.isArray(kind) || typeof kind === "number" ? kind : (this.patterns[kind] || this.patterns.tap);
      if (!this.supported) return false;
      try {
        // A new vibration command replaces the old pattern by specification.
        // Sending the actual pattern directly is more reliable on Android OEM builds
        // that occasionally swallow a zero-length cancel immediately followed by a buzz.
        this.lastResult = navigator.vibrate(pattern) !== false;
        return this.lastResult;
      } catch (_) { this.lastResult = false; return false; }
    }
  }

  restoreState();
  const sound = new AudioDirector();
  const haptics = new Haptics();
  setInitialScene();
  bindImmersiveGate();
  bindNavigation();
  bindGlobalFeedback();
  bindOriginGame();
  bindMemoryGame();
  bindDecoderGame();
  bindBelanGame();
  bindMoodLab();
  bindSnackGame();
  bindRhythmGame();
  bindQuizGame();
  bindStatusGame();
  bindTetrisGame();
  bindBalloonGame();
  bindSleepGame();
  bindSecretHold();
  bindKissGame();
  bindPlan();
  bindStars();
  bindProposal();
  bindFinaleActions();
  syncAll();
  initMotion();
  initCanvas();
  registerServiceWorker();
  document.documentElement.classList.add("app-ready");

  function restoreState() {
    try {
      const saved = JSON.parse(localStorage.getItem(storageKey));
      if (!saved || typeof saved !== "object") return;
      if (typeof saved.photoFocused === "boolean") state.photoFocused = saved.photoFocused;
      if (Array.isArray(saved.photoMoments)) state.photoMoments = saved.photoMoments.filter((value) => Number.isInteger(value) && value >= 0 && value < 3);
      if (Array.isArray(saved.memories)) state.memories = saved.memories.filter((value) => Number.isInteger(value) && value >= 0 && value < 4);
      if (Number.isInteger(saved.decoderRound)) state.decoderRound = Math.max(0, Math.min(4, saved.decoderRound));
      if (Number.isInteger(saved.belanDodges)) state.belanDodges = Math.max(0, Math.min(5, saved.belanDodges));
      if (Array.isArray(saved.moods)) state.moods = saved.moods.slice(0, 2);
      if (Number.isFinite(saved.nakhra)) state.nakhra = Math.max(0, Math.min(100, saved.nakhra));
      if (Number.isInteger(saved.snacks)) state.snacks = Math.max(0, Math.min(6, saved.snacks));
      if (Number.isInteger(saved.rhythmStep)) state.rhythmStep = Math.max(0, Math.min(6, saved.rhythmStep));
      if (Number.isInteger(saved.quizRound)) state.quizRound = Math.max(0, Math.min(4, saved.quizRound));
      if (Number.isInteger(saved.tetrisLines)) state.tetrisLines = Math.max(0, Math.min(3, saved.tetrisLines));
      if (Array.isArray(saved.balloons)) state.balloons = saved.balloons.filter((value) => Number.isInteger(value) && value >= 0 && value < 4);
      if (Array.isArray(saved.dreams)) state.dreams = saved.dreams.filter((value) => Number.isInteger(value) && value >= 0 && value < 4);
      ["statusBg", "statusLine", "statusSticker", "plan", "planEmoji", "date", "time"].forEach((key) => { if (typeof saved[key] === "string") state[key] = saved[key]; });
      if (typeof saved.secret === "boolean") state.secret = saved.secret;
      if (Number.isInteger(saved.kisses)) state.kisses = Math.max(0, Math.min(5, saved.kisses));
      if (Array.isArray(saved.stars)) state.stars = saved.stars.filter((value) => Number.isInteger(value) && value >= 0 && value < 5);
      if (typeof saved.soundOn === "boolean") state.soundOn = saved.soundOn;
    } catch (_) {}
  }

  function saveState() {
    try { localStorage.setItem(storageKey, JSON.stringify(state)); } catch (_) {}
  }

  function bindImmersiveGate() {
    $("#enter-experience").addEventListener("click", async () => {
      const button = $("#enter-experience");
      if (button.disabled) return;
      button.disabled = true;
      button.querySelector("span").textContent = "Music + fullscreen bula rahe hain…";
      setGateStatus("Bas ek second, BuBu. Browser ko tame kiya ja raha hai.");
      const hapticReady = haptics.prime();
      setGateCheck("#haptic-check", hapticReady, hapticReady ? "physical buzz sent ✓" : "needs hosted HTTPS");

      const fullscreenPromise = requestFullscreenConfirmed();
      const musicPromise = sound.startConfirmed();
      const [fullscreenReady, musicReady] = await Promise.all([fullscreenPromise, musicPromise]);
      setGateCheck("#music-check", musicReady, musicReady ? "playing ✓" : "blocked • retry");
      setGateCheck("#fullscreen-check", fullscreenReady, fullscreenReady ? "active ✓" : "blocked • retry");

      if (fullscreenReady && musicReady) {
        setGateStatus("Done. Ab story tumhari hai 💗");
        sound.sfx("sparkle");
        const gate = $("#immersive-gate");
        gate.classList.add("is-leaving");
        setTimeout(() => {
          gate.hidden = true;
          document.body.classList.remove("is-gated");
          animateScene(currentScene);
        }, reduceMotion ? 20 : 690);
        return;
      }

      button.disabled = false;
      button.querySelector("span").textContent = "Retry—dono ON chahiye";
      setGateStatus(!musicReady ? "Volume on karke phir tap karo. Chrome ko music permission chahiye." : "Fullscreen permission allow karke phir tap karo.");
    });
  }

  function setGateCheck(selector, ready, copy) {
    const node = $(selector);
    node.classList.toggle("is-ready", ready);
    node.querySelector("small").textContent = copy;
  }

  function setGateStatus(message) { const node = $("#gate-status"); if (node) node.textContent = message; }

  async function requestFullscreenConfirmed() {
    if (document.fullscreenElement || document.webkitFullscreenElement) return true;
    const root = document.documentElement;
    const request = root.requestFullscreen || root.webkitRequestFullscreen;
    if (!request) return false;
    try {
      let result;
      try { result = request.call(root, { navigationUI: "hide" }); }
      catch (_) { result = request.call(root); }
      if (result && typeof result.then === "function") await result;
      if (window.screen?.orientation?.lock) window.screen.orientation.lock("portrait").catch(() => {});
      return true;
    } catch (_) { return false; }
  }

  function setInitialScene() {
    const fromHash = location.hash.replace("#", "");
    const initial = scenes.has(fromHash) ? fromHash : "home";
    swapScene(initial, false);
    try { history.replaceState({ scene: initial }, "", "#" + initial); }
    catch (_) { location.hash = initial; }
  }

  function bindNavigation() {
    document.addEventListener("click", (event) => {
      const trigger = event.target.closest("[data-go]");
      if (!trigger) return;
      event.preventDefault();
      goTo(trigger.dataset.go);
    });
    $("#back-button").addEventListener("click", () => {
      const index = sceneOrder.indexOf(currentScene);
      goTo(sceneOrder[Math.max(0, index - 1)]);
    });
    $("#home-button").addEventListener("click", () => goTo("home"));
    $("#fullscreen-button").addEventListener("click", async () => {
      if (document.fullscreenElement && document.exitFullscreen) await document.exitFullscreen().catch(() => {});
      else if (!(await requestFullscreenConfirmed())) showToast("Chrome ne fullscreen block kiya. Ek baar phir tap karo.");
    });
    $("#sound-button").addEventListener("click", () => sound.setEnabled(!sound.enabled));
    window.addEventListener("popstate", (event) => {
      const requested = event.state?.scene || location.hash.replace("#", "");
      goTo(scenes.has(requested) ? requested : "home", { push: false });
    });
  }

  function goTo(name, options = {}) {
    if (!scenes.has(name)) return;
    if (name === currentScene) { window.scrollTo({ top: 0, behavior: reduceMotion ? "auto" : "smooth" }); return; }
    if (transitionLocked) { queuedScene = name; return; }
    const push = options.push !== false;
    if (push) {
      try { history.pushState({ scene: name }, "", "#" + name); }
      catch (_) { location.hash = name; }
    }
    runTransition(name);
  }

  function runTransition(name) {
    const transition = $("#route-transition");
    const vehicle = $("#chaos-vehicle");
    const route = transitionRoutes[Math.floor(Math.random() * transitionRoutes.length)];
    $("#chaos-ride").textContent = route.ride;
    $("#chaos-cargo").textContent = route.cargo;
    $("#transition-caption").textContent = route.text;
    transitionLocked = true;
    sound.sfx("page");
    haptics.pulse([58, 34, 76]);

    const complete = () => {
      transition.style.visibility = "hidden";
      transition.style.pointerEvents = "none";
      transitionLocked = false;
      if (queuedScene && queuedScene !== currentScene) {
        const next = queuedScene;
        queuedScene = "";
        goTo(next);
      }
    };

    if (hasGsap && !reduceMotion) {
      window.gsap.timeline({ onComplete: complete })
        .set(transition, { visibility: "visible", pointerEvents: "auto" })
        .set(vehicle, { xPercent: -175, y: 35, rotate: -12, scale: .7 })
        .fromTo("#transition-caption", { opacity: 0, y: 16, scale: .9 }, { opacity: 1, y: 0, scale: 1, duration: .28, ease: "back.out(1.4)" }, .2)
        .to(vehicle, { xPercent: -50, y: 0, rotate: 3, scale: 1, duration: .52, ease: "back.out(1.3)" }, 0)
        .add(() => swapScene(name, true), .56)
        .to(vehicle, { xPercent: 190, y: -55, rotate: 12, scale: .78, duration: .44, ease: "power3.in" }, .53)
        .to("#transition-caption", { opacity: 0, y: -12, duration: .2 }, .61)
        .to(transition, { opacity: 0, duration: .25 }, .72)
        .set(transition, { opacity: 1 });
      return;
    }

    transition.style.visibility = "visible";
    transition.style.pointerEvents = "auto";
    const animation = vehicle.animate?.([
      { transform: "translate(-190%,-50%) rotate(-12deg) scale(.72)" },
      { offset: .5, transform: "translate(-50%,-50%) rotate(3deg) scale(1)" },
      { transform: "translate(190%,-72%) rotate(12deg) scale(.8)" }
    ], { duration: reduceMotion ? 30 : 850, easing: "cubic-bezier(.2,.8,.2,1)" });
    setTimeout(() => swapScene(name, true), reduceMotion ? 5 : 420);
    setTimeout(complete, reduceMotion ? 35 : 900);
    if (animation) animation.oncancel = complete;
  }

  function swapScene(name, animate) {
    if (name !== currentScene) exitSceneMechanic(currentScene);
    killScrollMotion();
    scenes.forEach((scene, key) => {
      const active = key === name;
      scene.hidden = !active;
      scene.classList.toggle("is-active", active);
      scene.setAttribute("aria-hidden", String(!active));
    });
    currentScene = name;
    $("#home-button small").textContent = sceneModes[name] || "cute chaos";
    $("#progress-fill").style.width = (sceneOrder.indexOf(name) / (sceneOrder.length - 1) * 100) + "%";
    $("#back-button").hidden = name === "home";
    window.scrollTo(0, 0);
    enterSceneMechanic(name);
    if (name === "jaguar") renderRhythm();
    if (name === "final") { updateChosenPlan(); resetProposal(); }
    if (animate && !document.body.classList.contains("is-gated")) requestAnimationFrame(() => animateScene(name));
    setTimeout(() => $("#app").focus({ preventScroll: true }), reduceMotion ? 0 : 520);
  }

  // One scene owns one interaction mode. Every live timer/gesture has exactly one
  // entry point and one cleanup path, so games cannot leak into the next chapter.
  function enterSceneMechanic(name) {
    const starters = { snacks: prepareSnackGame, belan: prepareBelanGame, tetris: prepareTetrisGame, kisses: prepareKissGame };
    starters[name]?.();
  }

  function exitSceneMechanic(name) {
    if (name === "snacks") { stopSnackGame(); snackStarted = false; }
    if (name === "belan") { stopBelanGame(); belanStarted = false; }
    if (name === "tetris") { stopTetrisGame(); tetrisStarted = false; tetrisLocked = false; }
    if (name === "kisses") { stopKissRun(); kissStarted = false; }
    if (name === "balloons") resetBowInteraction(true);
    if (name === "secret") stopSecretHold();
  }

  function initMotion() {
    if (!hasGsap || reduceMotion) return;
    if (hasScrollTrigger) window.gsap.registerPlugin(window.ScrollTrigger);
    window.gsap.fromTo(".app-bar", { y: -64, opacity: 0 }, { y: 0, opacity: 1, duration: .8, ease: "power3.out" });
    window.gsap.utils.toArray(".floating-love span").forEach((item, index) => {
      window.gsap.to(item, { x: index % 2 ? 14 : -12, y: index % 3 ? -19 : 15, rotate: index % 2 ? 20 : -19, duration: 2.6 + index % 3, repeat: -1, yoyo: true, ease: "sine.inOut" });
    });
  }

  function animateScene(name) {
    if (!hasGsap || reduceMotion) return;
    const scene = scenes.get(name);
    if (!scene) return;
    const items = scene.querySelectorAll(":scope > .scene__inner > .eyebrow, :scope > .scene__inner > .display, :scope > .scene__inner > .lede, :scope > .scene__inner > .game-shell, :scope > .scene__inner > .plan-grid, :scope > .scene__inner > .schedule-card, :scope > .scene__inner > .btn, :scope > .scene__inner > .final-letter, :scope > .scene__inner > .ring-stage, :scope > .scene__inner > .proposal-arena");
    window.gsap.fromTo(items, { opacity: 0, y: 34, scale: .985 }, { opacity: 1, y: 0, scale: 1, duration: .7, stagger: .06, ease: "power3.out", clearProps: "transform" });
    if (name === "memory") window.gsap.fromTo(".memory-token", { scale: 0, rotate: -65 }, { scale: 1, rotate: 0, duration: .62, stagger: .1, delay: .18, ease: "back.out(1.8)" });
    if (name === "final") window.gsap.fromTo(".ring-box", { y: 34, scale: .58 }, { y: 0, scale: 1, duration: 1, ease: "elastic.out(1,.34)" });
    initScrollMotion(scene);
  }

  function initScrollMotion(scene) {
    if (!hasScrollTrigger || reduceMotion) return;
    $$(".plan-grid button, .final-letter, .love-note, .schedule-card", scene).forEach((item, index) => {
      const tween = window.gsap.fromTo(item, { opacity: .3, y: 45, rotate: index % 2 ? 1.4 : -1.4 }, { opacity: 1, y: 0, rotate: 0, ease: "none", scrollTrigger: { trigger: item, start: "top 96%", end: "top 69%", scrub: .55 } });
      scrollTweens.push(tween);
    });
    window.ScrollTrigger.refresh();
  }

  function killScrollMotion() {
    scrollTweens.forEach((tween) => { tween.scrollTrigger?.kill(); tween.kill?.(); });
    scrollTweens = [];
  }

  function bindGlobalFeedback() {
    let lastTarget = null;
    let lastAt = 0;
    const press = (event) => {
      const target = event.target.closest("button, a, input, select");
      if (!target) return;
      if (target.disabled) return;
      const now = performance.now();
      if (target === lastTarget && now - lastAt < 45) return;
      lastTarget = target;
      lastAt = now;
      haptics.pulse(target.dataset.haptic || "tap");
      sound.sfx(target.dataset.sound || "tap");
      if (!reduceMotion && target.animate) target.animate([{ filter: "brightness(1)" }, { filter: "brightness(1.2)" }], { duration: 120, fill: "forwards" });
    };
    document.addEventListener("pointerdown", press, { capture: true, passive: true });
    // Touch fallback stays installed even on PointerEvent browsers; the 45 ms guard
    // deduplicates the compatibility event while covering odd Android WebViews.
    document.addEventListener("touchstart", press, { capture: true, passive: true });
    document.addEventListener("pointerup", (event) => {
      const target = event.target.closest("button, a, input, select");
      if (!target) return;
      if (!reduceMotion && target.animate) target.animate([{ filter: "brightness(1.2)" }, { filter: "brightness(1)" }], { duration: 240 });
      sparkleAt(event.clientX, event.clientY, 6);
    }, { passive: true });
    $("#haptic-test").addEventListener("click", () => {
      const worked = haptics.pulse("calibrate");
      showToast(worked ? "Physical vibration command sent 📳 Agar feel hua, V10 haptics live hain." : "Vibration API unavailable. Hosted HTTPS link ko Chrome mein directly kholo.");
      setGateCheck("#haptic-check", worked, worked ? "physical buzz sent ✓" : "API unavailable");
      sparkleBurst($("#haptic-test"), 13);
    });
  }

  function bindOriginGame() {
    const slider = $("#photo-focus");
    slider.addEventListener("input", (event) => {
      if (state.photoFocused) return;
      const value = Number(event.target.value);
      const distance = Math.abs(78 - value);
      const blur = Math.min(11, distance / 6.5);
      $("#first-photo").style.setProperty("--photo-blur", blur.toFixed(2) + "px");
      $("#photo-focus-label").textContent = distance <= 14 ? "bas thoda sa…" : (value < 45 ? "abhi blur hai…" : "almost there");
      haptics.pulse(distance <= 14 ? 52 : 38);
      if (distance <= 5) unlockPhotoFocus();
    });
    slider.addEventListener("change", saveState);
    $$("[data-photo-memory]").forEach((button) => button.addEventListener("click", () => {
      if (!state.photoFocused) return;
      const index = Number(button.dataset.photoMemory);
      if (!state.photoMoments.includes(index)) state.photoMoments.push(index);
      $("#origin-reveal").innerHTML = "<strong>Moment 0" + (index + 1) + "</strong><br>" + photoLines[index];
      haptics.pulse("emotional"); sound.sfx(index === 2 ? "piano" : "sparkle"); sparkleBurst(button, 18);
      saveState(); syncOrigin();
      if (state.photoMoments.length === 3) celebrate(34);
    }));
  }

  function unlockPhotoFocus() {
    if (state.photoFocused) return;
    state.photoFocused = true;
    const slider = $("#photo-focus");
    slider.value = "78";
    slider.disabled = true;
    $("#first-photo").style.setProperty("--photo-blur", "0px");
    $("#photo-focus-label").textContent = "there we are ♥";
    $("#origin-reveal").textContent = "Focus mil gaya. Ab photo ke andar blink karte teen moments tap karo.";
    haptics.pulse("emotional"); sound.sfx("camera"); celebrate(20); saveState(); syncOrigin();
  }

  function syncOrigin() {
    const focused = state.photoFocused;
    const frame = $("#first-photo");
    frame.classList.toggle("is-focused", focused);
    frame.style.setProperty("--photo-blur", focused ? "0px" : "11px");
    $("#photo-focus").disabled = focused;
    if (focused) $("#photo-focus").value = "78";
    $("#photo-focus-label").textContent = focused ? "there we are ♥" : "thoda blur hai…";
    $$("[data-photo-memory]").forEach((button) => {
      const found = state.photoMoments.includes(Number(button.dataset.photoMemory));
      button.disabled = !focused;
      button.classList.toggle("is-found", found);
      button.setAttribute("aria-pressed", String(found));
    });
    $("#origin-score").textContent = state.photoMoments.length + " / 3 MOMENTS";
    $("#origin-next").classList.toggle("is-hidden", state.photoMoments.length < 3);
    if (state.photoMoments.length === 3) $("#origin-reveal").innerHTML = "<strong>Origin unlocked.</strong><br>Us photo ke baad tum sirf memory nahi bani, Nainsi. Tum meri roz ki life ka context ban gayi.";
  }

  function bindMemoryGame() {
    $$("[data-memory]").forEach((button) => {
      button.addEventListener("click", () => {
        const index = Number(button.dataset.memory);
        const memory = memoryLines[index];
        if (!memory) return;
        if (!state.memories.includes(index)) state.memories.push(index);
        $("#memory-message").innerHTML = "<span>" + memory.emoji + "</span><p>" + memory.copy + "</p>";
        $("#panda-line").textContent = memory.panda;
        haptics.pulse(state.memories.length === 4 ? "success" : "heart");
        sparkleBurst(button, 15);
        syncMemory();
        saveState();
      });
    });
  }

  function syncMemory() {
    $("#memory-score").textContent = state.memories.length + " / 4";
    $$("[data-memory]").forEach((button) => {
      const found = state.memories.includes(Number(button.dataset.memory));
      button.classList.toggle("is-found", found);
      button.setAttribute("aria-pressed", String(found));
      button.querySelector("b").textContent = found ? "✓" : "?";
    });
    $("#memory-next").classList.toggle("is-hidden", state.memories.length < 4);
    if (state.memories.length === 4) $("#panda-line").textContent = "caught red-pawed";
  }

  function bindDecoderGame() {
    $$("[data-decoder]").forEach((button) => {
      button.addEventListener("click", () => {
        if (decoderLocked || state.decoderRound >= decoderCases.length) return;
        const item = decoderCases[state.decoderRound];
        const answer = Number(button.dataset.decoder);
        if (answer !== item.correct) {
          button.classList.remove("is-wrong"); void button.offsetWidth; button.classList.add("is-wrong");
          $("#decoder-feedback").textContent = "Panda: ‘ye response relationship mein deploy mat karna.’ 🐼";
          haptics.pulse("wrong"); sound.sfx("wrong"); return;
        }
        decoderLocked = true;
        button.classList.add("is-correct");
        $("#decoder-feedback").textContent = item.line;
        state.decoderRound += 1;
        $("#decoder-score").textContent = state.decoderRound + " hearts";
        sparkleBurst(button, 16); haptics.pulse("success"); sound.sfx("correct"); saveState();
        if (state.decoderRound >= decoderCases.length) {
          $("#decoder-prompt").textContent = "“Dudu language certified”";
          $("#decoder-next").classList.remove("is-hidden");
          $$("[data-decoder]").forEach((node) => { node.disabled = true; });
        } else setTimeout(renderDecoder, reduceMotion ? 10 : 620);
      });
    });
  }

  function renderDecoder() {
    decoderLocked = false;
    if (state.decoderRound >= decoderCases.length) {
      $("#decoder-round").textContent = "4";
      $("#decoder-score").textContent = "4 hearts";
      $("#decoder-prompt").textContent = "“Dudu language certified”";
      $("#decoder-feedback").textContent = "4/4. Relationship translator officially hired.";
      $("#decoder-next").classList.remove("is-hidden");
      return;
    }
    const item = decoderCases[state.decoderRound];
    $("#decoder-round").textContent = String(state.decoderRound + 1);
    $("#decoder-score").textContent = state.decoderRound + " hearts";
    $("#decoder-prompt").textContent = item.prompt;
    $("#decoder-feedback").textContent = "Correct Dudu response choose karo.";
    $$("[data-decoder]").forEach((button, index) => {
      button.disabled = false;
      button.classList.remove("is-correct", "is-wrong");
      button.querySelector("b").textContent = item.options[index];
    });
  }

  function bindBelanGame() {
    $("#belan-start").addEventListener("click", startBelanGame);
    $$("[data-lane]").forEach((button) => button.addEventListener("click", () => {
      if (!belanStarted || !belanRoundActive) return;
      const nextLane = Number(button.dataset.lane);
      if (nextLane !== belanRoundOrigin) belanMovedThisRound = true;
      duduLane = nextLane;
      $("#belan-stage").style.setProperty("--dudu-lane", String(duduLane));
      $$("[data-lane]").forEach((node) => node.classList.toggle("is-active", Number(node.dataset.lane) === duduLane));
      haptics.pulse("move");
    }));
  }

  function prepareBelanGame() {
    stopBelanGame();
    belanStarted = false;
    belanRoundActive = false;
    belanMovedThisRound = false;
    $("#belan-ready").hidden = state.belanDodges >= 5;
    $("#belan-game").classList.remove("is-running");
    if (state.belanDodges < 5) $("#belan-feedback").textContent = "Pehle heading padh lo. Ready ho tabhi Nainsi belan launch karegi.";
    syncBelan();
  }

  function startBelanGame() {
    stopBelanGame();
    syncBelan();
    if (state.belanDodges >= 5) return;
    belanStarted = true;
    $("#belan-ready").hidden = true;
    $("#belan-game").classList.add("is-running", "is-counting");
    $("#belan-feedback").textContent = "Countdown ke baad belan dikhega. Har throw par ek nayi safe lane tap karna!";
    const countdown = $("#belan-countdown");
    const count = countdown.querySelector("b");
    const note = countdown.querySelector("small");
    countdown.hidden = false;
    count.textContent = "3";
    note.textContent = "ready rehna";
    [[430, "2"], [860, "1"], [1290, "DODGE!"]].forEach(([delay, copy]) => {
      const timer = setTimeout(() => {
        count.textContent = copy;
        note.textContent = copy === "DODGE!" ? "belan incoming" : "ready rehna";
        count.style.animation = "none";
        void count.offsetWidth;
        count.style.animation = "";
      }, delay);
      belanTimers.push(timer);
    });
    belanTimers.push(setTimeout(() => { countdown.hidden = true; }, 1710));
    scheduleBelan(1480);
  }

  function scheduleBelan(delay = 620) {
    if (currentScene !== "belan" || !belanStarted || state.belanDodges >= 5) return;
    const launch = setTimeout(() => {
      if (currentScene !== "belan" || !belanStarted) return;
      belanLane = Math.floor(Math.random() * 3);
      belanRoundOrigin = duduLane;
      belanMovedThisRound = false;
      belanRoundActive = true;
      $("#belan-game").classList.remove("is-counting");
      const belan = $("#falling-belan");
      belan.style.setProperty("--belan-lane", String(belanLane));
      belan.classList.remove("is-falling"); void belan.offsetWidth; belan.classList.add("is-falling");
      $("#belan-callout").textContent = ["‘Seedhe raho, Bapch*da!’", "‘Ab belan batayega!’", "‘Dudu… bhaago mat!’"][Math.floor(Math.random() * 3)];
      sound.sfx("whoosh");
      const impact = setTimeout(resolveBelan, 1010);
      belanTimers.push(impact);
    }, delay);
    belanTimers.push(launch);
  }

  function resolveBelan() {
    if (currentScene !== "belan" || !belanStarted || state.belanDodges >= 5) return;
    belanRoundActive = false;
    $("#falling-belan").classList.remove("is-falling");
    const cleanDodge = belanMovedThisRound && belanLane !== duduLane;
    if (!cleanDodge) {
      $("#dudu-dodger").classList.remove("is-hit"); void $("#dudu-dodger").offsetWidth; $("#dudu-dodger").classList.add("is-hit");
      $("#bonk-star").classList.remove("is-live"); void $("#bonk-star").offsetWidth; $("#bonk-star").classList.add("is-live");
      $("#belan-feedback").textContent = !belanMovedThisRound ? "BONK. Khade rehna dodge nahi tha, Golu Baby. Har throw par move karna padega." : "BONK. Galat lane. Nainsi: ‘Bola tha na, Bapch*da.’ Again!";
      haptics.pulse("bonk"); sound.sfx("belan");
    } else {
      state.belanDodges += 1;
      $("#belan-feedback").textContent = state.belanDodges < 5 ? "Clean dodge! Teddy-Dudu ka survival instinct finally online." : "Five actual dodges. Nainsi ne belan side rakha… temporarily.";
      haptics.pulse("success"); sound.sfx("correct"); sparkleBurst($("#dudu-dodger"), 13); saveState(); syncBelan();
    }
    if (state.belanDodges < 5) scheduleBelan(760);
    else {
      belanStarted = false;
      $("#belan-game").classList.remove("is-running");
      celebrate(30);
    }
  }

  function stopBelanGame() {
    belanTimers.forEach(clearTimeout);
    belanTimers = [];
    belanRoundActive = false;
    belanMovedThisRound = false;
    $("#falling-belan")?.classList.remove("is-falling");
    const countdown = $("#belan-countdown");
    if (countdown) countdown.hidden = true;
    $("#belan-game")?.classList.remove("is-counting");
  }

  function syncBelan() {
    $("#belan-score").textContent = state.belanDodges + " / 5";
    $("#belan-next").classList.toggle("is-hidden", state.belanDodges < 5);
    $("#belan-stage").style.setProperty("--dudu-lane", String(duduLane));
    $$("[data-lane]").forEach((button) => button.classList.toggle("is-active", Number(button.dataset.lane) === duduLane));
    if (state.belanDodges >= 5) {
      $("#belan-ready").hidden = true;
      $("#belan-feedback").textContent = "Dudu survived. Five actual dodges—Belan ko paid leave mil gayi.";
    }
  }

  function bindMoodLab() {
    $$("[data-mood]").forEach((button) => {
      button.addEventListener("click", () => {
        const mood = button.dataset.mood;
        if (state.moods.includes(mood)) state.moods = state.moods.filter((item) => item !== mood);
        else if (state.moods.length >= 2) { showToast("Bas do, BuBu. Dudu ko bhi planning ka ek chance do."); shake($(".mood-grid")); return; }
        else state.moods.push(mood);
        syncMood(); saveState();
      });
    });
    $("#nakhra-range").addEventListener("input", (event) => { state.nakhra = Number(event.target.value); syncMood(); haptics.pulse(38); });
    $("#nakhra-range").addEventListener("change", saveState);
    $("#mood-next").addEventListener("click", () => {
      if (state.moods.length < 2) { showToast("Do vibes choose karni hain, BuBu—HUD fake decoration nahi hai."); shake($(".mood-lab")); return; }
      goTo("snacks");
    });
  }

  function nakhraText() {
    if (state.nakhra < 22) return "seedhi bacchi";
    if (state.nakhra < 55) return "cute sa drama";
    if (state.nakhra < 83) return "full nakhra mode";
    return "certified menace";
  }

  function syncMood() {
    $$("[data-mood]").forEach((button) => button.setAttribute("aria-pressed", String(state.moods.includes(button.dataset.mood))));
    $("#mood-score").textContent = state.moods.length + " / 2";
    $("#nakhra-range").value = String(state.nakhra);
    $("#nakhra-label").textContent = nakhraText();
  }

  function bindSnackGame() {
    $("#snack-start").addEventListener("click", startSnackGame);
  }

  function prepareSnackGame() {
    stopSnackGame();
    snackStarted = false;
    $("#snack-game").classList.remove("is-running");
    $("#snack-ready").hidden = state.snacks >= 6;
    if (state.snacks < 6) $("#snack-feedback").textContent = "Instructions padh lo; Panda tab tak snacks ko hawa mein nahi fekega.";
    syncSnacks();
  }

  function startSnackGame() {
    stopSnackGame();
    if (state.snacks >= 6) { syncSnacks(); return; }
    snackStarted = true;
    $("#snack-game").classList.add("is-running");
    $("#snack-ready").hidden = true;
    $("#snack-feedback").textContent = "Catch mode ON. Yummy cheezein tap; green imposters ko ignore!";
    spawnSnack(true);
    snackTimer = setInterval(() => spawnSnack(false), 560);
  }

  function stopSnackGame() {
    clearInterval(snackTimer);
    snackTimer = 0;
    $$(".falling-snack", $("#snack-stage")).forEach((item) => item.remove());
    $("#snack-game")?.classList.remove("is-running");
  }

  function spawnSnack(forceGood) {
    if (currentScene !== "snacks" || !snackStarted || state.snacks >= 6) return;
    const good = ["🥘", "🍫", "☕", "🍰", "🧁", "🥐"];
    const bad = ["🥦", "🥒", "🥬"];
    const isGood = forceGood || Math.random() > .29;
    const button = document.createElement("button");
    button.type = "button";
    button.className = "falling-snack" + (isGood ? "" : " is-bad");
    button.dataset.good = String(isGood);
    button.textContent = (isGood ? good : bad)[Math.floor(Math.random() * (isGood ? good.length : bad.length))];
    button.style.left = (4 + Math.random() * 82) + "%";
    button.style.setProperty("--fall", (3.1 + Math.random() * 1.5) + "s");
    button.style.setProperty("--drift", (-35 + Math.random() * 70) + "px");
    button.style.setProperty("--spin", (280 + Math.random() * 430) + "deg");
    $("#snack-stage").appendChild(button);
    button.addEventListener("click", () => {
      if (button.classList.contains("is-caught")) return;
      button.classList.add("is-caught");
      if (button.dataset.good === "true") {
        state.snacks += 1;
        $("#snack-feedback").textContent = state.snacks < 6 ? "Nice catch. Panda ka plate emotionally stable ho raha hai." : "Plate full. Panda ne ek pastry already chhupa li.";
        $("#snack-comment").textContent = state.snacks < 6 ? state.snacks + " yummy things" : "mission complete";
        haptics.pulse("success"); sound.sfx("pop"); sparkleBurst(button, 12); saveState(); syncSnacks();
        if (state.snacks >= 6) { stopSnackGame(); snackStarted = false; $("#snack-game").classList.remove("is-running"); }
      } else {
        $("#snack-feedback").textContent = "Karela detected. BuBu ne respectfully reject kar diya.";
        haptics.pulse("wrong"); sound.sfx("wrong");
      }
      setTimeout(() => button.remove(), 340);
    });
    setTimeout(() => button.remove(), 4900);
  }

  function syncSnacks() {
    $("#snack-score").textContent = state.snacks + " / 6";
    $("#snack-next").classList.toggle("is-hidden", state.snacks < 6);
    if (state.snacks >= 6) { $("#snack-ready").hidden = true; $("#snack-comment").textContent = "mission complete"; $("#snack-feedback").textContent = "Six favourites secured. Karela got zero screen time."; }
  }

  function bindRhythmGame() {
    $$("[data-pad]").forEach((button) => {
      button.addEventListener("click", () => {
        if (state.rhythmStep >= rhythmPattern.length) return;
        const pad = Number(button.dataset.pad);
        if (pad !== rhythmPattern[state.rhythmStep]) {
          $("#rhythm-feedback").textContent = "DJ Panda: ‘off-beat, but cute.’ Glowing pad dekho.";
          haptics.pulse("wrong"); sound.sfx("wrong"); shake(button); return;
        }
        state.rhythmStep += 1;
        $("#rhythm-feedback").textContent = rhythmLines[state.rhythmStep - 1];
        $("#jaguar-line").textContent = state.rhythmStep < 6 ? "speed " + state.rhythmStep + " / 6" : "BuBu on tour";
        $("#jaguar-car").style.setProperty("--car-x", state.rhythmStep * 31 + "px");
        sparkleBurst(button, 12); haptics.pulse("success"); saveState(); renderRhythm();
        if (state.rhythmStep >= 6) { sound.sfx("car"); celebrate(28); }
      });
    });
  }

  function renderRhythm() {
    $("#rhythm-score").textContent = state.rhythmStep + " / 6";
    $("#rhythm-next").classList.toggle("is-hidden", state.rhythmStep < 6);
    $$("[data-pad]").forEach((button) => {
      const live = state.rhythmStep < 6 && Number(button.dataset.pad) === rhythmPattern[state.rhythmStep];
      button.classList.toggle("is-live", live);
      button.disabled = state.rhythmStep >= 6;
    });
    $("#jaguar-car").style.setProperty("--car-x", state.rhythmStep * 31 + "px");
    if (state.rhythmStep >= 6) { $("#jaguar-line").textContent = "BuBu on tour"; $("#rhythm-feedback").textContent = "Jaguar unlocked. Aux Nainsi ki, forever."; }
  }

  function bindQuizGame() {
    $$("[data-answer]").forEach((button) => {
      button.addEventListener("click", () => {
        if (quizLocked || state.quizRound >= quizQuestions.length) return;
        const item = quizQuestions[state.quizRound];
        const answer = Number(button.dataset.answer);
        if (answer !== item.correct) {
          button.classList.remove("is-wrong"); void button.offsetWidth; button.classList.add("is-wrong");
          $("#quiz-feedback").textContent = "Panda: ‘hmm… fake news.’ Ek aur guess.";
          haptics.pulse("wrong"); sound.sfx("wrong"); return;
        }
        quizLocked = true;
        button.classList.add("is-correct");
        $$("[data-answer]").forEach((node) => { node.disabled = true; });
        $("#quiz-feedback").textContent = item.line;
        state.quizRound += 1;
        $("#quiz-score").textContent = state.quizRound + " hearts";
        $("#quiz-next").classList.toggle("is-hidden", state.quizRound >= 4);
        $("#quiz-finish").classList.toggle("is-hidden", state.quizRound < 4);
        sparkleBurst(button, 16); haptics.pulse("success"); sound.sfx("correct"); saveState();
        if (state.quizRound >= 4) { $("#quiz-panda").textContent = "🐼🏆"; celebrate(26); }
      });
    });
    $("#quiz-next").addEventListener("click", renderQuiz);
  }

  function renderQuiz() {
    quizLocked = false;
    if (state.quizRound >= 4) {
      $("#quiz-round").textContent = "4";
      $("#quiz-score").textContent = "4 hearts";
      $("#quiz-question").textContent = "Panda verdict: tum Dudu ko suspiciously well jaanti ho.";
      $("#quiz-feedback").textContent = "4/4. Prize: romantic status laboratory unlocked.";
      $("#quiz-panda").textContent = "🐼🏆";
      $("#quiz-finish").classList.remove("is-hidden");
      return;
    }
    const item = quizQuestions[state.quizRound];
    $("#quiz-round").textContent = String(state.quizRound + 1);
    $("#quiz-score").textContent = state.quizRound + " hearts";
    $("#quiz-question").textContent = item.question;
    $("#quiz-feedback").textContent = "Answer lock karo, Cutiepiee.";
    $("#quiz-panda").textContent = "🐼";
    $("#quiz-next").classList.add("is-hidden");
    $$("[data-answer]").forEach((button, index) => {
      button.disabled = false;
      button.classList.remove("is-correct", "is-wrong");
      button.querySelector("b").textContent = item.options[index];
    });
  }

  function bindStatusGame() {
    $$("[data-status-bg]").forEach((button) => button.addEventListener("click", () => { state.statusBg = button.dataset.statusBg; syncStatus(); saveState(); }));
    $$("[data-status-line]").forEach((button) => button.addEventListener("click", () => { state.statusLine = button.dataset.statusLine; syncStatus(); saveState(); }));
    $$("[data-status-sticker]").forEach((button) => button.addEventListener("click", () => { state.statusSticker = button.dataset.statusSticker; syncStatus(); saveState(); }));
  }

  function syncStatus() {
    $("#status-preview").dataset.bg = state.statusBg || "berry";
    $("#status-line").textContent = state.statusLine || "choose a line, BuBu";
    $("#status-sticker").textContent = state.statusSticker || "💗";
    $$("[data-status-bg]").forEach((button) => button.setAttribute("aria-pressed", String(button.dataset.statusBg === state.statusBg)));
    $$("[data-status-line]").forEach((button) => button.setAttribute("aria-pressed", String(button.dataset.statusLine === state.statusLine)));
    $$("[data-status-sticker]").forEach((button) => button.setAttribute("aria-pressed", String(button.dataset.statusSticker === state.statusSticker)));
    const count = [state.statusBg, state.statusLine, state.statusSticker].filter(Boolean).length;
    $("#status-feedback").textContent = count === 3 ? "Status ready. Dudu replay counter: already embarrassing." : count + " / 3 ingredients selected";
    $("#status-next").classList.toggle("is-hidden", count < 3);
  }

  function bindTetrisGame() {
    $("#tetris-start").addEventListener("click", () => {
      if (state.tetrisLines >= 3) return;
      tetrisStarted = true;
      $("#tetris-ready").hidden = true;
      $("#tetris-game").classList.add("is-running");
      $("#tetris-feedback").textContent = "Game ON—heart-piece ko glowing gap ke upar align karo.";
      startTetrisGame();
    });
    $("#tetris-left").addEventListener("click", () => moveTetris(-1));
    $("#tetris-right").addEventListener("click", () => moveTetris(1));
    $("#tetris-rotate").addEventListener("click", rotateTetris);
    $("#tetris-drop").addEventListener("click", dropTetris);
  }

  function tetrisGap() { return [2, 0, 4][Math.min(state.tetrisLines, 2)]; }
  function tetrisStartCol() { return [0, 4, 1][Math.min(state.tetrisLines, 2)]; }
  function tetrisMaxRow() { return tetrisPiece.vertical ? 6 : 7; }

  function prepareTetrisGame() {
    stopTetrisGame();
    tetrisStarted = false;
    tetrisLocked = false;
    $("#tetris-ready").hidden = state.tetrisLines >= 3;
    $("#tetris-game").classList.remove("is-running");
    if (state.tetrisLines < 3) $("#tetris-feedback").textContent = "Instructions padh lo; start dabane tak koi block nahi girega.";
    renderTetris();
  }

  function resetTetrisPiece() {
    tetrisLocked = false;
    tetrisPiece = { row: 0, col: tetrisStartCol(), vertical: false };
    renderTetris();
  }

  function startTetrisGame() {
    stopTetrisGame();
    if (!tetrisStarted) return;
    if (state.tetrisLines >= 3) { renderTetris(); return; }
    resetTetrisPiece();
    tetrisTimer = setInterval(() => {
      if (currentScene !== "tetris" || state.tetrisLines >= 3) { stopTetrisGame(); return; }
      if (tetrisPiece.row < tetrisMaxRow()) { tetrisPiece.row += 1; renderTetris(); }
      else resolveTetrisDrop();
    }, 820);
  }

  function stopTetrisGame() { clearInterval(tetrisTimer); tetrisTimer = 0; }

  function moveTetris(direction) {
    if (!tetrisStarted || state.tetrisLines >= 3 || tetrisLocked) return;
    const width = tetrisPiece.vertical ? 1 : 2;
    tetrisPiece.col = Math.max(0, Math.min(6 - width, tetrisPiece.col + direction));
    renderTetris();
  }

  function rotateTetris() {
    if (!tetrisStarted || state.tetrisLines >= 3 || tetrisLocked) return;
    tetrisPiece.vertical = !tetrisPiece.vertical;
    tetrisPiece.col = Math.min(tetrisPiece.col, tetrisPiece.vertical ? 5 : 4);
    tetrisPiece.row = Math.min(tetrisPiece.row, tetrisMaxRow());
    $("#tetris-hint").textContent = tetrisPiece.vertical ? "cute chaos, but line horizontal hai" : "yes—ab gap align karo";
    renderTetris();
  }

  function dropTetris() {
    if (!tetrisStarted || state.tetrisLines >= 3 || tetrisLocked) return;
    tetrisLocked = true;
    stopTetrisGame();
    tetrisPiece.row = tetrisMaxRow();
    renderTetris();
    setTimeout(resolveTetrisDrop, 120);
  }

  function resolveTetrisDrop() {
    if (tetrisLocked && state.tetrisLines >= 3) return;
    tetrisLocked = true;
    stopTetrisGame();
    const correct = !tetrisPiece.vertical && tetrisPiece.col === tetrisGap();
    if (!correct) {
      $("#tetris-feedback").textContent = tetrisPiece.vertical ? "Vertical mood cute tha, but LOVE line horizontal complete hogi. Again." : "Piece side mein land hua. Glowing gap ko aim karo, BuBu.";
      haptics.pulse("wrong"); sound.sfx("wrong"); shake($("#tetris-board"));
      setTimeout(startTetrisGame, 520);
      return;
    }

    $$(".tetris-cell", $("#tetris-board")).slice(42, 48).forEach((cell) => cell.classList.add("is-clearing"));
    state.tetrisLines += 1;
    $("#tetris-feedback").textContent = state.tetrisLines < 3 ? "Love-line complete! " + state.tetrisLines + "/3 — next gap, next little effort." : "Teen lines complete. Pieces alag the; picture ek hi bani: US. 💗";
    haptics.pulse("emotional"); sound.sfx("drop"); saveState();
    setTimeout(() => {
      renderTetris();
      if (state.tetrisLines < 3) startTetrisGame();
      else { tetrisStarted = false; $("#tetris-game").classList.remove("is-running"); $("#tetris-game").classList.add("is-complete"); celebrate(48); }
    }, 560);
  }

  function renderTetris() {
    const board = $("#tetris-board");
    if (!board.children.length) {
      for (let index = 0; index < 48; index += 1) {
        const cell = document.createElement("i");
        cell.className = "tetris-cell";
        cell.setAttribute("role", "gridcell");
        board.appendChild(cell);
      }
    }
    const cells = $$(".tetris-cell", board);
    cells.forEach((cell) => cell.className = "tetris-cell");
    $("#tetris-score").textContent = state.tetrisLines + " / 3";
    $("#tetris-next").classList.toggle("is-hidden", state.tetrisLines < 3);
    $("#tetris-game").classList.toggle("is-complete", state.tetrisLines >= 3);
    if (state.tetrisLines >= 3) {
      $("#tetris-ready").hidden = true;
      cells.forEach((cell, index) => { if (index >= 30) cell.classList.add("is-fixed"); });
      $("#tetris-next-piece").textContent = "US 💗";
      $("#tetris-hint").textContent = "complete";
      return;
    }
    const gap = tetrisGap();
    for (let col = 0; col < 6; col += 1) {
      const cell = cells[7 * 6 + col];
      cell.classList.add(col === gap || col === gap + 1 ? "is-gap" : "is-fixed");
    }
    const active = tetrisPiece.vertical
      ? [[tetrisPiece.row, tetrisPiece.col], [tetrisPiece.row + 1, tetrisPiece.col]]
      : [[tetrisPiece.row, tetrisPiece.col], [tetrisPiece.row, tetrisPiece.col + 1]];
    active.forEach(([row, col]) => { const cell = cells[row * 6 + col]; if (cell) cell.classList.add("is-active"); });
    $("#tetris-next-piece").textContent = tetrisPiece.vertical ? "💗\n💗" : "💗💗";
  }

  function bindBalloonGame() {
    const bow = $("#bow-control");
    const sky = $("#balloon-sky");
    const updateCharge = () => {
      const percent = Math.min(100, Math.round(bowPull / 88 * 100));
      $("#bow-charge-fill").style.width = percent + "%";
      $("#bow-charge-label").textContent = bowPull >= 30 ? "RELEASE! " + percent + "%" : (bowPull ? "CHARGING " + percent + "%" : "HOLD TO CHARGE");
      sky.classList.toggle("is-charged", bowPull >= 30);
      if (bowPull >= 30 && !bowChargedBuzzed) {
        bowChargedBuzzed = true;
        haptics.pulse([38, 24, 58]);
        sound.sfx("sparkle");
      }
    };
    const drawCharge = () => {
      if (!bowStart || bowShooting) return;
      const held = performance.now() - bowStart.time;
      bowPull = Math.max(bowPull, Math.min(88, held / 6.2));
      bow.style.setProperty("--pull", bowPull.toFixed(0) + "px");
      updateCharge();
      bowChargeFrame = requestAnimationFrame(drawCharge);
    };
    const move = (event) => {
      if (!bowStart || bowShooting || event.pointerId !== bowStart.pointerId) return;
      event.preventDefault();
      const distance = Math.hypot(event.clientX - bowStart.x, event.clientY - bowStart.y);
      bowPull = Math.max(bowPull, Math.min(88, distance));
      bow.style.setProperty("--pull", bowPull.toFixed(0) + "px");
      updateCharge();
    };
    const release = (event) => {
      if (!bowStart || bowShooting || (event.pointerId != null && event.pointerId !== bowStart.pointerId)) return;
      event.preventDefault?.();
      cancelAnimationFrame(bowChargeFrame);
      const pointerId = bowStart.pointerId;
      const strength = bowPull;
      bowStart = null;
      bowPull = 0;
      try { if (bow.hasPointerCapture?.(pointerId)) bow.releasePointerCapture(pointerId); } catch (_) {}
      bow.classList.remove("is-pulling");
      sky.classList.remove("is-aiming", "is-charged");
      document.documentElement.classList.remove("bow-dragging");
      bow.style.setProperty("--pull", "0px");
      $("#bow-charge-fill").style.width = "0%";
      $("#bow-charge-label").textContent = "HOLD TO CHARGE";
      bowChargedBuzzed = false;
      if (strength < 30) { $("#gift-secret p").textContent = "Thoda aur hold ya pull karo, Cupid. 0.3 second mein bow charge ho jayega."; haptics.pulse("wrong"); sound.sfx("wrong"); return; }
      shootBalloon(strength);
    };
    bow.addEventListener("pointerdown", (event) => {
      if (bowShooting || state.balloons.length >= 4) return;
      event.preventDefault();
      bowStart = { x: event.clientX, y: event.clientY, time: performance.now(), pointerId: event.pointerId };
      bowPull = 0;
      bowChargedBuzzed = false;
      try { bow.setPointerCapture?.(event.pointerId); } catch (_) {}
      bow.classList.add("is-pulling");
      sky.classList.add("is-aiming");
      document.documentElement.classList.add("bow-dragging");
      $("#gift-secret p").textContent = "Charge bar gold hote hi finger chhod dena—Cupid ready hai.";
      updateCharge();
      cancelAnimationFrame(bowChargeFrame);
      bowChargeFrame = requestAnimationFrame(drawCharge);
    });
    document.addEventListener("pointermove", move, { passive: false });
    document.addEventListener("pointerup", release, { passive: false });
    document.addEventListener("pointercancel", release, { passive: false });
    sky.addEventListener("touchmove", (event) => { if (bowStart) event.preventDefault(); }, { passive: false });
    bow.addEventListener("contextmenu", (event) => event.preventDefault());
    bow.addEventListener("dragstart", (event) => event.preventDefault());
    bow.addEventListener("click", (event) => event.preventDefault());
    bow.addEventListener("keydown", (event) => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); shootBalloon(70); } });
  }

  function resetBowInteraction(cancelFlight = false) {
    cancelAnimationFrame(bowChargeFrame);
    bowChargeFrame = 0;
    bowStart = null;
    bowPull = 0;
    bowChargedBuzzed = false;
    document.documentElement.classList.remove("bow-dragging");
    $("#balloon-sky")?.classList.remove("is-aiming", "is-charged");
    $("#bow-control")?.classList.remove("is-pulling");
    $("#bow-control")?.style.setProperty("--pull", "0px");
    if ($("#bow-charge-fill")) $("#bow-charge-fill").style.width = "0%";
    if ($("#bow-charge-label")) $("#bow-charge-label").textContent = "HOLD TO CHARGE";
    if (!cancelFlight) return;
    bowShooting = false;
    clearTimeout(bowFlightTimer);
    bowFlightTimer = 0;
    try { bowFlightAnimation?.cancel?.(); } catch (_) {}
    bowFlightAnimation = null;
    const arrow = $("#flying-arrow");
    if (arrow) { arrow.style.opacity = "0"; arrow.style.transform = "none"; }
  }

  function shootBalloon(strength) {
    const target = $$("[data-balloon]").find((balloon) => !state.balloons.includes(Number(balloon.dataset.balloon)));
    if (!target || bowShooting) return;
    bowShooting = true;
    const arrow = $("#flying-arrow");
    const stage = $("#balloon-sky");
    arrow.style.opacity = "1";
    const stageRect = stage.getBoundingClientRect();
    const targetRect = target.getBoundingClientRect();
    const startX = stageRect.width / 2;
    const startY = stageRect.height - 104;
    const endX = targetRect.left - stageRect.left + targetRect.width / 2;
    const endY = targetRect.top - stageRect.top + targetRect.height * .35;
    const dx = endX - startX;
    const dy = endY - startY;
    const angle = Math.atan2(dy, dx) * 180 / Math.PI;
    sound.sfx("bow"); haptics.pulse("bow");
    const duration = Math.max(300, 610 - strength * 2.3);
    const animation = arrow.animate?.([
      { opacity: 1, transform: "translate(0,0) rotate(" + angle + "deg) scale(.85)" },
      { opacity: 1, transform: "translate(" + dx + "px," + dy + "px) rotate(" + angle + "deg) scale(1.05)" }
    ], { duration, easing: "cubic-bezier(.16,.72,.25,1)", fill: "forwards" });
    const hit = () => {
      if (!bowShooting) return;
      arrow.style.opacity = "0";
      arrow.style.transform = "none";
      popBalloon(Number(target.dataset.balloon));
      bowShooting = false;
      bowFlightAnimation = null;
      bowFlightTimer = 0;
    };
    if (animation) { bowFlightAnimation = animation; animation.onfinish = hit; }
    else bowFlightTimer = setTimeout(hit, duration);
  }

  function popBalloon(index) {
    if (state.balloons.includes(index)) return;
    state.balloons.push(index);
    const balloon = $("[data-balloon='" + index + "']");
    balloon.classList.add("is-popped");
    $("#gift-secret").innerHTML = "<span>" + ["🎁","🍫","🍰","💌"][index] + "</span><p>" + balloonSecrets[index] + "</p>";
    haptics.pulse("emotional"); sound.sfx("balloon");
    setTimeout(() => sound.sfx("gift"), 300);
    sparkleBurst(balloon, 24); saveState(); syncBalloons();
    if (state.balloons.length === 4) celebrate(42);
  }

  function syncBalloons() {
    $$("[data-balloon]").forEach((balloon) => balloon.classList.toggle("is-popped", state.balloons.includes(Number(balloon.dataset.balloon))));
    $("#balloon-score").textContent = state.balloons.length + " / 4";
    $("#balloon-next").classList.toggle("is-hidden", state.balloons.length < 4);
    if (state.balloons.length >= 4) $("#gift-secret").innerHTML = "<span>💌</span><p>Last secret: in sab games ke peeche simple si baat hai—main tumhe sirf impress nahi, properly feel karwana chahta hoon ki tum loved ho.</p>";
  }

  function bindSleepGame() {
    $$("[data-dream]").forEach((button) => button.addEventListener("click", () => {
      const index = Number(button.dataset.dream);
      if (!state.dreams.includes(index)) state.dreams.push(index);
      $("#sleep-whisper").textContent = dreamLines[index];
      haptics.pulse("emotional"); sound.sfx("sleep"); sparkleBurst(button, 16); saveState(); syncSleep();
      if (state.dreams.length === 4) celebrate(36);
    }));
  }

  function syncSleep() {
    $$("[data-dream]").forEach((button) => {
      const found = state.dreams.includes(Number(button.dataset.dream));
      button.classList.toggle("is-found", found);
      button.setAttribute("aria-pressed", String(found));
    });
    $("#sleep-score").textContent = state.dreams.length + " / 4";
    $("#sleep-next").classList.toggle("is-hidden", state.dreams.length < 4);
    if (state.dreams.length === 4) $("#sleep-whisper").textContent = "Tum so rahi hoti ho toh mujhe tumse kuch chahiye nahi hota. Bas woh quiet sa privilege—tumhare paas hone ka.";
  }

  function bindSecretHold() {
    const button = $("#hold-button");
    const stage = $("#hold-stage");
    const duration = 1200;
    const cancel = () => {
      cancelAnimationFrame(holdFrame);
      clearInterval(holdPulse);
      holdFrame = 0; holdPulse = 0;
      stage.classList.remove("is-holding");
      if (!state.secret) { button.style.setProperty("--hold-offset", "415"); $("#hold-caption").textContent = "almost—1.2 seconds tak wahi"; }
    };
    const tick = (time) => {
      const progress = Math.min(1, (time - holdStart) / duration);
      button.style.setProperty("--hold-offset", String(415 * (1 - progress)));
      if (progress >= 1) { cancel(); revealSecret(true); return; }
      holdFrame = requestAnimationFrame(tick);
    };
    button.addEventListener("pointerdown", (event) => {
      if (state.secret) return;
      event.preventDefault();
      button.setPointerCapture?.(event.pointerId);
      stage.classList.add("is-holding");
      $("#hold-caption").textContent = "bas aise hi… note khul rahi hai";
      holdStart = performance.now();
      haptics.pulse("hold"); sound.sfx("piano");
      holdPulse = setInterval(() => haptics.pulse(42), 230);
      holdFrame = requestAnimationFrame(tick);
    });
    button.addEventListener("pointerup", cancel);
    button.addEventListener("pointercancel", cancel);
    button.addEventListener("lostpointercapture", () => { if (!state.secret) cancel(); });
    button.addEventListener("contextmenu", (event) => event.preventDefault());
    $("#hold-fallback").addEventListener("click", () => {
      holdFallbackTaps += 1;
      if (holdFallbackTaps < 3) { showToast((3 - holdFallbackTaps) + " aur tap. Haan, backup mein bhi nakhre."); return; }
      revealSecret(true);
    });
  }

  function stopSecretHold() {
    cancelAnimationFrame(holdFrame);
    clearInterval(holdPulse);
    holdFrame = 0;
    holdPulse = 0;
    if (!state.secret) {
      $("#hold-stage")?.classList.remove("is-holding");
      $("#hold-button")?.style.setProperty("--hold-offset", "415");
    }
  }

  function revealSecret(withCelebration) {
    state.secret = true;
    $("#hold-stage").classList.add("is-holding");
    $("#hold-button").style.setProperty("--hold-offset", "0");
    $("#hold-caption").textContent = "unlocked • gently padhna";
    $("#love-note").hidden = false;
    $("#hold-fallback").classList.add("is-hidden");
    $("#secret-next").classList.remove("is-hidden");
    saveState();
    if (withCelebration) { haptics.pulse("success"); sound.sfx("correct"); celebrate(25); }
  }

  function bindKissGame() {
    $("#kiss-start").addEventListener("click", () => {
      if (state.kisses >= 5) return;
      kissStarted = true;
      $("#kiss-ready").hidden = true;
      $("#kiss-game").classList.add("is-running");
      $("#kiss-taunt").textContent = "Ab pakad ke dikhao, BuBu 😏";
      startKissRun();
    });
    $("#kiss-target").addEventListener("click", () => {
      if (!kissStarted || state.kisses >= 5) return;
      state.kisses += 1;
      $("#kiss-score").textContent = String(state.kisses);
      $("#kiss-taunt").textContent = kissTaunts[state.kisses - 1];
      haptics.pulse(state.kisses === 5 ? "success" : [68, 42, 92]);
      sparkleBurst($("#kiss-target"), 15); saveState(); syncKisses();
      if (state.kisses < 5) { moveKiss(true); startKissRun(); }
      else { kissStarted = false; stopKissRun(); $("#kiss-game").classList.remove("is-running"); sound.sfx("correct"); celebrate(32); }
    });
  }

  function prepareKissGame() {
    stopKissRun();
    kissStarted = false;
    $("#kiss-ready").hidden = state.kisses >= 5;
    $("#kiss-game").classList.remove("is-running");
    if (state.kisses < 5) {
      $("#kiss-target").style.left = "50%";
      $("#kiss-target").style.top = "51%";
      $("#kiss-taunt").textContent = "Pehle instructions padh lo. Start ke baad main bhaagungi.";
    }
    syncKisses();
  }

  function moveKiss(fast) {
    if (currentScene !== "kisses" || state.kisses >= 5) return;
    const button = $("#kiss-target");
    const previousX = parseFloat(button.style.left) || 50;
    const previousY = parseFloat(button.style.top) || 51;
    let x = 17 + Math.random() * 66;
    let y = 25 + Math.random() * 51;
    if (Math.abs(x - previousX) < 21) x = x < 50 ? Math.min(82, x + 28) : Math.max(18, x - 28);
    if (Math.abs(y - previousY) < 15) y = y < 52 ? Math.min(77, y + 21) : Math.max(26, y - 21);
    button.classList.toggle("is-zipping", fast);
    button.style.left = x.toFixed(1) + "%";
    button.style.top = y.toFixed(1) + "%";
    if (fast) setTimeout(() => button.classList.remove("is-zipping"), 170);
  }

  function startKissRun() {
    stopKissRun();
    if (!kissStarted || state.kisses >= 5 || currentScene !== "kisses") return;
    moveKiss(false);
    const schedule = () => {
      if (!kissStarted || state.kisses >= 5 || currentScene !== "kisses") return;
      moveKiss(false);
      kissTimer = setTimeout(schedule, Math.max(360, 570 - state.kisses * 38));
    };
    kissTimer = setTimeout(schedule, 500);
  }

  function stopKissRun() { clearTimeout(kissTimer); kissTimer = 0; }

  function syncKisses() {
    $("#kiss-score").textContent = String(state.kisses);
    $("#kiss-next").classList.toggle("is-hidden", state.kisses < 5);
    if (state.kisses >= 5) {
      $("#kiss-ready").hidden = true;
      $("#kiss-target span").textContent = "💖";
      $("#kiss-target").style.left = "50%";
      $("#kiss-target").style.top = "51%";
      $("#kiss-taunt").textContent = kissTaunts[4];
    }
  }

  function bindPlan() {
    $$("[data-plan]").forEach((button) => button.addEventListener("click", () => {
      state.plan = button.dataset.plan;
      state.planEmoji = button.dataset.emoji || "🎁";
      syncPlan(); saveState(); sparkleBurst(button, 11);
    }));
    $("#date-input").addEventListener("change", (event) => { state.date = event.target.value; saveState(); });
    $("#time-input").addEventListener("change", (event) => { state.time = event.target.value; saveState(); });
    $("#plan-next").addEventListener("click", () => {
      if (!state.plan) { showToast("Pehle ek plan choose karo. Surprise wala fully valid hai."); shake($(".plan-grid")); return; }
      state.date = $("#date-input").value;
      state.time = $("#time-input").value;
      saveState(); goTo("stars");
    });
  }

  function syncPlan() {
    $$("[data-plan]").forEach((button) => button.setAttribute("aria-pressed", String(button.dataset.plan === state.plan)));
    const today = new Date();
    const localToday = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
    $("#date-input").min = localToday;
    $("#date-input").value = state.date;
    $("#time-input").value = state.time;
  }

  function bindStars() {
    $$("[data-star]").forEach((button) => button.addEventListener("click", () => {
      const index = Number(button.dataset.star);
      if (!state.stars.includes(index)) state.stars.push(index);
      $("#star-message").textContent = state.stars.length + " / 5 • " + starLines[index];
      haptics.pulse("heart"); sound.sfx(index % 2 ? "piano" : "sparkle"); sparkleBurst(button, 15); saveState(); syncStars();
      if (state.stars.length === 5) celebrate(35);
    }));
  }

  function syncStars() {
    $$("[data-star]").forEach((button) => button.classList.toggle("is-lit", state.stars.includes(Number(button.dataset.star))));
    $("#star-path").style.setProperty("--path-offset", String(720 * (1 - state.stars.length / 5)));
    $("#stars-next").classList.toggle("is-hidden", state.stars.length < 5);
    if (state.stars.length === 5) $("#star-message").textContent = "5 / 5 • No grand claim. Bas daily tumhe choose karne ka plan.";
  }

  function updateChosenPlan() {
    const parts = [state.plan ? state.planEmoji + " " + state.plan : "🎁 Dudu’s surprise"];
    if (state.date) {
      const parsed = new Date(state.date + "T12:00:00");
      parts.push(new Intl.DateTimeFormat("en-IN", { day: "numeric", month: "short", year: "numeric" }).format(parsed));
    }
    if (state.time) parts.push(state.time);
    $("#chosen-plan").textContent = parts.join(" • ");
    $("#whatsapp-button").href = "https://wa.me/+917004804153";
  }

  function bindProposal() {
    $("#proposal-yes").addEventListener("click", () => {
      if (proposalRuns < 5) {
        proposalRuns += 1;
        const positions = [[27,26],[72,30],[29,63],[72,65],[50,45]];
        const labels = ["Nope, idhar 😛","Too slow, BuBu","Jaguar speed chahiye","Almost, Chhutku","Okay ab pakdo: YES 💍"];
        const lines = [
          "Aise seedha yes? Thoda bhaav toh banta hai.", "Ring ka security audit chal raha hai, madam ji.",
          "Panda: ‘prove your reflexes.’ 🐼", "Dudu ka dil already fast chal raha hai.", "Last time. Ab pakda toh forever wala yes."
        ];
        const button = $("#proposal-yes");
        button.style.left = positions[proposalRuns - 1][0] + "%";
        button.style.top = positions[proposalRuns - 1][1] + "%";
        button.textContent = labels[proposalRuns - 1];
        $("#proposal-tease").textContent = lines[proposalRuns - 1];
        haptics.pulse([72,44,98]); sound.sfx(proposalRuns % 2 ? "guitar" : "piano"); sparkleBurst(button, 12);
        return;
      }
      acceptProposal();
    });
  }

  function resetProposal() {
    proposalRuns = 0;
    const button = $("#proposal-yes");
    button.textContent = "Yes, Dudu 💍";
    button.style.left = "50%";
    button.style.top = "38%";
    $("#proposal-tease").textContent = "Yes thoda tumhare jaisa hai—pehle bhaav khayega.";
  }

  function acceptProposal() {
    haptics.pulse([90,65,125,70,190]); sound.sfx("finale");
    const finale = $("#finale");
    finale.hidden = false;
    finale.setAttribute("aria-hidden", "false");
    document.body.classList.add("finale-open");
    $("#finale-copy").hidden = false;
    $("#walkout").classList.remove("is-live");
    $("#finale-actions").hidden = true;
    launchConfetti(110);
    finaleTimers.forEach(clearTimeout); finaleTimers = [];
    if (reduceMotion) { showFinaleActions(); return; }
    finaleTimers.push(setTimeout(() => {
      $("#finale-copy").hidden = true;
      $("#walkout").classList.add("is-live");
      haptics.pulse("heart"); sound.sfx("page");
    }, 2300));
    finaleTimers.push(setTimeout(() => {
      $("#walkout").classList.remove("is-live");
      showFinaleActions();
    }, 8900));
  }

  function showFinaleActions() {
    $("#finale-copy").hidden = true;
    $("#walkout").classList.remove("is-live");
    $("#finale-actions").hidden = false;
    haptics.pulse("success"); launchConfetti(55);
    if (hasGsap && !reduceMotion) window.gsap.fromTo("#finale-actions", { opacity: 0, y: 32 }, { opacity: 1, y: 0, duration: .75, ease: "back.out(1.3)" });
  }

  function bindFinaleActions() {
    $("#screenshot-button").addEventListener("click", enterScreenshotMode);
    $("#restart-button").addEventListener("click", () => {
      Object.assign(state, { photoFocused: false, photoMoments: [], memories: [], decoderRound: 0, belanDodges: 0, moods: [], nakhra: 42, snacks: 0, rhythmStep: 0, quizRound: 0, statusBg: "", statusLine: "", statusSticker: "", tetrisLines: 0, balloons: [], dreams: [], secret: false, kisses: 0, plan: "", planEmoji: "🎁", date: "", time: "", stars: [] });
      holdFallbackTaps = 0; decoderLocked = false; quizLocked = false;
      finaleTimers.forEach(clearTimeout); finaleTimers = [];
      $("#finale").hidden = true;
      document.body.classList.remove("finale-open", "screenshot-mode");
      resetTransientUI(); saveState(); syncAll(); goTo("home");
    });
  }

  function enterScreenshotMode() {
    if (document.body.classList.contains("screenshot-mode")) return;
    sound.sfx("camera"); haptics.pulse("success"); showToast("Clean frame in 3… 2… 1…");
    setTimeout(() => {
      document.body.classList.add("screenshot-mode");
      $("#screenshot-tip").hidden = false;
      setTimeout(() => { $("#screenshot-tip").hidden = true; }, 1800);
      setTimeout(() => {
        screenshotHandler = () => {
          document.body.classList.remove("screenshot-mode");
          $("#screenshot-tip").hidden = true;
          screenshotHandler = null;
        };
        document.addEventListener("pointerdown", screenshotHandler, { once: true, capture: true });
      }, 650);
    }, 500);
  }

  function resetTransientUI() {
    stopSnackGame(); stopBelanGame(); stopTetrisGame(); stopKissRun(); resetProposal();
    stopSecretHold();
    snackStarted = false; belanStarted = false; tetrisStarted = false; kissStarted = false; tetrisLocked = false;
    resetBowInteraction(true);
    ["#snack-ready", "#belan-ready", "#tetris-ready", "#kiss-ready"].forEach((selector) => { $(selector).hidden = false; });
    ["#belan-game", "#tetris-game", "#kiss-game"].forEach((selector) => $(selector).classList.remove("is-running"));
    duduLane = 1;
    $("#first-photo").classList.remove("is-focused");
    $("#first-photo").style.setProperty("--photo-blur", "11px");
    $("#photo-focus").disabled = false;
    $("#photo-focus").value = "0";
    $("#origin-reveal").textContent = "Pehle photo ko focus karo. Phir iske andar chhupe 3 moments tap karna.";
    $("#belan-feedback").textContent = "Lane choose karo. Belan ka aim suspiciously accurate hai.";
    $("#belan-callout").textContent = "‘Seedhe raho, Bapch*da!’";
    $("#tetris-feedback").textContent = "First heart-piece ko glowing gap ke upar set karo.";
    $("#tetris-board").innerHTML = "";
    $("#gift-secret").innerHTML = "<span>🎁</span><p>First balloon ka secret tumhara wait kar raha hai.</p>";
    $("#sleep-whisper").textContent = "Chaar sleepy expressions gently tap karo. BuBu ko jagana nahi.";
    $("#memory-message").innerHTML = "<span>🐾</span><p>Panda ko pakdo; evidence uske paas hai.</p>";
    $("#panda-line").textContent = "main? bilkul innocent.";
    $("#decoder-next").classList.add("is-hidden");
    $("#snack-feedback").textContent = "Favourite pe tap. Karela ko respect se ignore.";
    $("#snack-comment").textContent = "plate ready hai";
    $("#rhythm-feedback").textContent = "Jo pad glow kare, wahi tap. DJ Panda strict hai.";
    $("#love-note").hidden = true;
    $("#hold-fallback").classList.remove("is-hidden");
    $("#secret-next").classList.add("is-hidden");
    $("#hold-button").style.setProperty("--hold-offset", "415");
    $("#hold-caption").textContent = "finger yahin • 1.2 seconds";
    $("#kiss-target span").textContent = "💋";
    $("#kiss-taunt").textContent = kissTaunts[0];
  }

  function syncAll() {
    syncOrigin(); syncMemory(); renderDecoder(); syncBelan(); syncMood(); syncSnacks(); renderRhythm(); renderQuiz(); syncStatus(); renderTetris(); syncBalloons(); syncSleep();
    if (state.secret) revealSecret(false);
    syncKisses(); syncPlan(); syncStars(); updateSoundButton();
  }

  function updateSoundButton() {
    const muted = !sound.enabled || !state.soundOn;
    document.body.classList.toggle("music-muted", muted);
    $("#sound-button").classList.toggle("is-muted", muted);
    $("#sound-button").setAttribute("aria-pressed", String(!muted));
    $("#sound-button").setAttribute("aria-label", muted ? "Play music" : "Pause music");
    $("#sound-button").textContent = muted ? "♪" : "♫";
  }

  function showToast(message) {
    clearTimeout(toastTimer);
    const toast = $("#toast");
    toast.textContent = message;
    toast.classList.remove("is-live"); void toast.offsetWidth; toast.classList.add("is-live");
    toastTimer = setTimeout(() => toast.classList.remove("is-live"), 2800);
  }

  function shake(element) {
    if (!element) return;
    haptics.pulse("wrong");
    if (hasGsap && !reduceMotion) { window.gsap.fromTo(element, { x: -7 }, { x: 7, duration: .07, repeat: 5, yoyo: true, clearProps: "x" }); return; }
    element.animate?.([{ transform: "translateX(-6px)" }, { transform: "translateX(6px)" }, { transform: "translateX(0)" }], { duration: 290 });
  }

  function sparkleBurst(element, count = 10) {
    if (!element) return;
    const rect = element.getBoundingClientRect();
    sparkleAt(rect.left + rect.width / 2, rect.top + rect.height / 2, count);
  }

  function sparkleAt(x, y, count = 8) {
    if (reduceMotion) return;
    const symbols = ["✦", "✧", "♥", "·", "♡"];
    for (let index = 0; index < count; index += 1) {
      const item = document.createElement("span");
      const angle = Math.PI * 2 * index / count + Math.random() * .45;
      const distance = 28 + Math.random() * 62;
      item.className = "tap-spark";
      item.textContent = symbols[Math.floor(Math.random() * symbols.length)];
      item.style.left = x + "px"; item.style.top = y + "px"; item.style.setProperty("--size", 9 + Math.random() * 12 + "px");
      $("#tap-sparkles").appendChild(item);
      const dx = Math.cos(angle) * distance;
      const dy = Math.sin(angle) * distance - 15;
      const animation = item.animate?.([
        { transform: "translate(-50%,-50%) scale(.35) rotate(0)", opacity: 0 },
        { offset: .18, opacity: 1 },
        { transform: "translate(calc(-50% + " + dx + "px),calc(-50% + " + dy + "px)) scale(1.15) rotate(" + (120 + Math.random() * 160) + "deg)", opacity: 0 }
      ], { duration: 650 + Math.random() * 380, easing: "cubic-bezier(.2,.7,.2,1)" });
      if (animation) animation.onfinish = () => item.remove(); else setTimeout(() => item.remove(), 900);
    }
  }

  function celebrate(count = 28) {
    if (reduceMotion) return;
    for (let index = 0; index < count; index += 1) setTimeout(() => sparkleAt(Math.random() * innerWidth, 70 + Math.random() * innerHeight * .7, 3), index * 24);
  }

  function launchConfetti(count) {
    const layer = $("#confetti-layer");
    const colors = ["#ff4f9d", "#ffd36f", "#a8f5d5", "#b68cff", "#fff9f6"];
    for (let index = 0; index < count; index += 1) {
      const piece = document.createElement("i");
      piece.className = "confetti-piece";
      piece.style.left = Math.random() * 100 + "%";
      piece.style.background = colors[index % colors.length];
      piece.style.setProperty("--fall", 3.2 + Math.random() * 3 + "s");
      piece.style.setProperty("--drift", -70 + Math.random() * 140 + "px");
      piece.style.setProperty("--turn", 420 + Math.random() * 600 + "deg");
      piece.style.animationDelay = Math.random() * .8 + "s";
      layer.appendChild(piece);
      setTimeout(() => piece.remove(), 7200);
    }
  }

  function initCanvas() {
    if (reduceMotion) return;
    const canvas = $("#love-canvas");
    const context = canvas.getContext("2d");
    if (!context) return;
    let width = 0, height = 0, ratio = 1, particles = [], frame = 0;
    const make = () => ({ x: Math.random() * width, y: Math.random() * height, size: 1 + Math.random() * 2.6, speed: .08 + Math.random() * .29, drift: -.13 + Math.random() * .26, alpha: .12 + Math.random() * .5, phase: Math.random() * Math.PI * 2, heart: Math.random() > .78 });
    const resize = () => {
      ratio = Math.min(devicePixelRatio || 1, 2); width = innerWidth; height = innerHeight;
      canvas.width = Math.floor(width * ratio); canvas.height = Math.floor(height * ratio);
      canvas.style.width = width + "px"; canvas.style.height = height + "px";
      context.setTransform(ratio, 0, 0, ratio, 0, 0);
      particles = Array.from({ length: Math.max(34, Math.min(72, Math.floor(width / 6))) }, make);
    };
    const draw = () => {
      frame += 1; context.clearRect(0, 0, width, height);
      particles.forEach((particle) => {
        particle.y -= particle.speed; particle.x += particle.drift + Math.sin(frame * .008 + particle.phase) * .05;
        if (particle.y < -20) { particle.y = height + 20; particle.x = Math.random() * width; }
        context.globalAlpha = particle.alpha * (.62 + Math.sin(frame * .025 + particle.phase) * .38);
        if (particle.heart) { context.fillStyle = "#ff70ad"; context.font = 7 + particle.size * 3 + "px Georgia"; context.fillText("♥", particle.x, particle.y); }
        else { const glow = context.createRadialGradient(particle.x,particle.y,0,particle.x,particle.y,particle.size*2.5); glow.addColorStop(0,particle.phase>Math.PI?"#ffd477":"#ff77b1"); glow.addColorStop(1,"rgba(255,100,170,0)"); context.fillStyle=glow; context.beginPath(); context.arc(particle.x,particle.y,particle.size*2.5,0,Math.PI*2); context.fill(); }
      });
      context.globalAlpha = 1; requestAnimationFrame(draw);
    };
    resize(); addEventListener("resize", resize, { passive: true }); requestAnimationFrame(draw);
  }

  function registerServiceWorker() {
    if (!("serviceWorker" in navigator)) return;
    if (location.protocol !== "https:" && location.hostname !== "localhost") return;
    addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(() => {}));
  }

  document.addEventListener("visibilitychange", () => { if (document.hidden) sound.pauseForVisibility(); else sound.resumeForVisibility(); });
})();

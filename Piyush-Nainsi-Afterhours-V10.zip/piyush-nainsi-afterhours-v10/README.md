# Piyush × Nainsi — Afterhours V10

A mobile-first, 18-scene playable love story made for Nainsi by Piyush. V10 makes every timed game explicitly opt-in, fixes mobile Cupid gestures, pre-decodes instant interaction audio, strengthens Android haptics, and keeps every chapter in one non-overlapping interaction mode.

## Open it locally

1. Extract the full ZIP first.
2. Open the extracted `piyush-nainsi-afterhours-v10` folder.
3. Tap `index.html` and choose Chrome.
4. Tap the opening button once. That real gesture starts music, requests fullscreen, and sends a physical haptic test.

Do not open `index.html` while it is still inside the ZIP. Fullscreen, vibration, offline caching, and reload behavior are most reliable from the hosted HTTPS link.

## Update the existing GitHub Pages site (recommended)

Do **not** create a new repository if V8 is already live. Reuse the same repository so Nainsi's public link stays unchanged.

### Easiest once the included V10 workflow is in the repo

1. Open your existing repository on GitHub.
2. Open **Code → Add file → Upload files**.
3. Select the single `Piyush-Nainsi-Afterhours-V10.zip` file. Do not unzip it for this method.
4. In **Commit changes**, enter `Upgrade love story to V10`, choose **Commit directly to the main branch**, and commit.
5. The workflow automatically chooses the newest `Piyush-Nainsi-Afterhours-V*.zip`, extracts it, and deploys the folder containing `index.html`.
6. Open **Actions → Deploy P × N Afterhours** and wait for the green check.
7. Open **Settings → Pages**. The unchanged public URL appears under **Your site is live at**.
8. On Nainsi's phone, open that link directly in Chrome and refresh once. V10's new service-worker key replaces the old build cache.

If the repository still has an older workflow that cannot unpack ZIP files, replace `.github/workflows/deploy-pages.yml` once with the file bundled in this project. After that, every future upgrade can be one ZIP upload.

### Standard extracted-files method

Extract the ZIP, then use **Code → Add file → Upload files** to upload the **contents inside** `piyush-nainsi-afterhours-v10`. `index.html` must appear at the repository root. Let files with the same names replace the old edition and commit to `main`.

## Publish as a brand-new site

Only use this path if no old site exists, or if you deliberately want a second URL.

1. GitHub home → **+** → **New repository**.
2. Repository name: `nainsi-afterhours`.
3. Choose **Public**, leave template options unchecked, then tap **Create repository**.
4. **Add file → Upload files** and upload the extracted folder's contents so `index.html` is at the root. This also installs the included workflow.
5. Commit to `main` with message `Publish Piyush and Nainsi V10`.
6. Open **Settings → Pages**.
7. Under **Build and deployment → Source**, select **GitHub Actions**.
8. Open **Actions → Deploy P × N Afterhours → Run workflow → Run workflow** if it did not start automatically.
9. Your link will be `https://YOUR-USERNAME.github.io/nainsi-afterhours/`.

## What V10 includes

- One compulsory opening gesture for music, fullscreen, and haptic calibration
- Original 127-second, 320 kbps cinematic romantic soundtrack; no music picker
- 24 locally bundled 256 kbps context-specific interaction effects, pre-decoded with low-latency Web Audio
- 18 scenes with 14 interaction/game chapters
- First-picture focus puzzle and emotional timeline hotspots
- Panda memory heist, Nainsi-language decoder, and a manual-start five-round Belan dodge with a visible countdown
- Snack catch, Jaguar rhythm, relationship quiz, and WhatsApp status creator
- Three-line Love Tetris and mobile-safe Cupid archery with scroll lock, pointer capture, and a live charge bar
- Animated sleep-gaze scene built from the supplied reference image
- Fast five-catch kiss chase, date builder, constellation promises, and runaway proposal button
- Panda and Teddy holding hands and walking into a clipped portal without right-side overflow
- Hash routing, 404 fallback, PWA manifest, V10 service-worker cache, and GitHub Pages workflow
- MECE lifecycle cleanup: only the current chapter can own a timer, drag, animation flight, or hold gesture

## Haptics and browser reality

V10 sends longer, distinct `navigator.vibrate()` patterns directly from `pointerdown`, synchronized with each MP3 effect. A deduplicated `touchstart` fallback covers unusual Android WebViews. The opening screen reports whether Chrome accepted the vibration command. Android Chrome on the hosted HTTPS page is the target. Browser code can request vibration but cannot override Silent/DND, Battery Saver, system vibration intensity, unsupported WebViews, or an OEM setting.

If the opening haptic check says **physical buzz sent** but nothing is felt, open the actual `https://...github.io/.../` address directly in Chrome—not a WhatsApp in-app viewer or `content://` download preview—then check Android **Settings → Sound & vibration → Vibration & haptics**.

## Audio note

The soundtrack and effects are original generated assets bundled for reliable offline playback. No commercial recording or copyrighted song lyrics are redistributed.

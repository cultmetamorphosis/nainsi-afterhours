# Afterhours V10 — QA and MECE map

## What was re-audited

- All 18 scene IDs, routes, back/home navigation, hash reloads, and gated CTAs
- Manual-start lifecycle for Belan Dodge, Snack Catch, Love Tetris, and Kiss Chase
- Belan scoring: no input = no point; hit lane = no point; moved safe lane = one point; unlock only at 5
- Mobile Cupid input: arena-wide `touch-action: none`, pointer capture, document-level release, cancellation cleanup, and visible charge state
- Low-latency feedback: interaction MP3s pre-decoded through Web Audio, audible-onset analysis, and sound dispatched on `pointerdown`
- Android haptics: direct vibration patterns on `pointerdown` plus a deduplicated `touchstart` fallback
- Image dimensions, local asset paths, MP3 decodability/bitrate, service-worker cache version, GitHub Pages workflow, and JavaScript syntax

Run `python3 audit_v10.py` inside this folder to repeat the automated audit.

## MECE interaction ownership

Every chapter has one primary job; no chapter timer owns another chapter's screen.

| Scene | Only interaction mode | Completion rule |
|---|---|---|
| Home | Start | Opening CTA |
| Origin | Focus | Slider + 3 photo moments |
| Memory | Discover | 4 Panda clues |
| Scold | Decode | 4 correct replies |
| Belan | Dodge | Start explicitly + 5 actual safe moves |
| Mood | Choose | Exactly 2 vibes |
| Snacks | Catch | Start explicitly + 6 good snacks |
| Jaguar | Rhythm | 6 beats in order |
| Quiz | Know | 4 correct answers |
| Status | Create | Color + line + sticker |
| Tetris | Build | Start explicitly + 3 love lines |
| Balloons | Aim | Pull/release 4 arrows |
| Sleep | Feel | 4 sleepy expressions |
| Secret | Hold | 1.2-second hold or 3-tap fallback |
| Kisses | Chase | Start explicitly + 5 catches |
| Plan | Plan | One date idea |
| Stars | Promise | 5 stars |
| Final | Forever | Catch Yes on attempt 6 |

When a scene exits, its timers, holds, pointer state, and in-flight animation are cancelled before the next scene becomes interactive.

## Device boundary

The package can verify that Chrome accepted `navigator.vibrate()`, but a desktop audit cannot physically measure a phone motor. For the real-device check, use the hosted HTTPS GitHub Pages link directly in Android Chrome—not WhatsApp's in-app browser or a `content://` download preview.

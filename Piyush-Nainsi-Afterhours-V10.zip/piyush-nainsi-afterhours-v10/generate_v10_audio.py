#!/usr/bin/env python3
"""Generate V10's original high-impact romantic score and zero-lag tactile game SFX."""

from __future__ import annotations

import math
import subprocess
import tempfile
from pathlib import Path

import numpy as np
from scipy.io import wavfile


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "assets" / "audio"
SR = 44_100
RNG = np.random.default_rng(1102)


def midi(note: float) -> float:
    return 440.0 * 2.0 ** ((note - 69.0) / 12.0)


def envelope(size: int, attack: float, release: float, curve: float = 1.0) -> np.ndarray:
    env = np.ones(size, dtype=np.float32)
    a = min(size, max(1, int(attack * SR)))
    r = min(size, max(1, int(release * SR)))
    env[:a] = np.linspace(0.0, 1.0, a, dtype=np.float32) ** curve
    env[-r:] *= np.linspace(1.0, 0.0, r, dtype=np.float32) ** curve
    return env


def oscillator(freq: float, size: int, kind: str = "warm", phase: float = 0.0) -> np.ndarray:
    t = np.arange(size, dtype=np.float32) / SR
    angle = 2.0 * np.pi * freq * t + phase
    if kind == "sine":
        return np.sin(angle)
    if kind == "bell":
        return (
            np.sin(angle)
            + 0.42 * np.sin(angle * 2.01 + 0.3)
            + 0.21 * np.sin(angle * 3.99 + 0.7)
            + 0.10 * np.sin(angle * 6.02)
        ) / 1.73
    if kind == "guitar":
        return (
            np.sin(angle)
            + 0.34 * np.sin(angle * 2.0 + 0.2)
            + 0.17 * np.sin(angle * 3.0 + 0.8)
            + 0.07 * np.sin(angle * 4.0)
        ) / 1.58
    if kind == "string":
        vibrato = 0.012 * np.sin(2.0 * np.pi * 5.1 * t)
        return (
            np.sin(angle + vibrato)
            + 0.29 * np.sin(angle * 2.0 + 0.5)
            + 0.12 * np.sin(angle * 3.0 + 1.1)
        ) / 1.41
    return (
        np.sin(angle)
        + 0.26 * np.sin(angle * 2.0 + 0.21)
        + 0.10 * np.sin(angle * 3.0 + 0.63)
    ) / 1.36


def add_note(
    mix: np.ndarray,
    start: float,
    duration: float,
    note: float,
    amp: float,
    pan: float = 0.0,
    kind: str = "warm",
    attack: float = 0.02,
    release: float = 0.20,
) -> None:
    left = max(0, int(start * SR))
    size = min(int(duration * SR), mix.shape[0] - left)
    if size <= 0:
        return
    signal = oscillator(midi(note), size, kind, RNG.random() * math.tau)
    signal *= envelope(size, attack, release, 0.72)
    # Equal-power stereo panning.
    angle = (float(np.clip(pan, -1, 1)) + 1.0) * np.pi / 4.0
    mix[left:left + size, 0] += signal * amp * np.cos(angle)
    mix[left:left + size, 1] += signal * amp * np.sin(angle)


def add_noise_hit(mix: np.ndarray, start: float, duration: float, amp: float, pan: float = 0.0) -> None:
    left = int(start * SR)
    size = min(int(duration * SR), mix.shape[0] - left)
    if size <= 0:
        return
    noise = RNG.normal(0, 1, size).astype(np.float32)
    noise = np.convolve(noise, np.ones(7, dtype=np.float32) / 7.0, mode="same")
    noise *= np.exp(-np.linspace(0, 9, size, dtype=np.float32))
    angle = (pan + 1.0) * np.pi / 4.0
    mix[left:left + size, 0] += noise * amp * np.cos(angle)
    mix[left:left + size, 1] += noise * amp * np.sin(angle)


def soften_and_master(mix: np.ndarray, *, reverb: bool = True) -> np.ndarray:
    if reverb:
        dry = mix.copy()
        for delay, gain, cross in [(0.095, 0.17, False), (0.171, 0.12, True), (0.263, 0.08, False), (0.387, 0.055, True)]:
            samples = int(delay * SR)
            if cross:
                mix[samples:, 0] += dry[:-samples, 1] * gain
                mix[samples:, 1] += dry[:-samples, 0] * gain
            else:
                mix[samples:] += dry[:-samples] * gain
    # Gentle low-pass smoothing, then tape-ish saturation.
    for _ in range(2):
        mix[1:] = 0.78 * mix[1:] + 0.22 * mix[:-1]
    mix = np.tanh(mix * 1.24)
    peak = float(np.max(np.abs(mix))) or 1.0
    return (mix / peak * 0.91).astype(np.float32)


def export_mp3(name: str, data: np.ndarray, bitrate: str = "256k") -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    pcm = (np.clip(data, -1, 1) * 32767).astype(np.int16)
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as handle:
        wav_path = Path(handle.name)
    wavfile.write(wav_path, SR, pcm)
    try:
        subprocess.run(
            [
                "ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(wav_path),
                "-codec:a", "libmp3lame", "-b:a", bitrate, "-ar", str(SR), "-ac", "2", str(OUT / name),
            ],
            check=True,
        )
    finally:
        wav_path.unlink(missing_ok=True)


def add_pitch_sweep(
    mix: np.ndarray,
    start: float,
    duration: float,
    start_hz: float,
    end_hz: float,
    amp: float,
    pan: float = 0.0,
    release: float = 0.12,
) -> None:
    left = max(0, int(start * SR))
    size = min(int(duration * SR), mix.shape[0] - left)
    if size <= 0:
        return
    frequencies = np.geomspace(max(1.0, start_hz), max(1.0, end_hz), size).astype(np.float32)
    phase = np.cumsum(2.0 * np.pi * frequencies / SR)
    signal = (np.sin(phase) + 0.25 * np.sin(phase * 2.0 + 0.4)) / 1.25
    signal *= envelope(size, 0.008, min(release, duration * 0.65), 0.72)
    angle = (float(np.clip(pan, -1, 1)) + 1.0) * np.pi / 4.0
    mix[left:left + size, 0] += signal * amp * np.cos(angle)
    mix[left:left + size, 1] += signal * amp * np.sin(angle)


def add_kick(mix: np.ndarray, start: float, amp: float = 0.30) -> None:
    left = int(start * SR)
    size = min(int(0.32 * SR), mix.shape[0] - left)
    if size <= 0:
        return
    t = np.arange(size, dtype=np.float32) / SR
    phase = 2.0 * np.pi * (72.0 * t + (118.0 - 72.0) * (1.0 - np.exp(-24.0 * t)) / 24.0)
    hit = np.sin(phase) * np.exp(-t * 14.5)
    click = RNG.normal(0, 1, size).astype(np.float32) * np.exp(-t * 78.0) * 0.12
    signal = (hit + click) * amp
    mix[left:left + size, 0] += signal
    mix[left:left + size, 1] += signal


def add_snare(mix: np.ndarray, start: float, amp: float = 0.12) -> None:
    left = int(start * SR)
    size = min(int(0.28 * SR), mix.shape[0] - left)
    if size <= 0:
        return
    t = np.arange(size, dtype=np.float32) / SR
    noise = RNG.normal(0, 1, size).astype(np.float32)
    noise -= np.convolve(noise, np.ones(21, dtype=np.float32) / 21.0, mode="same")
    tone = np.sin(2 * np.pi * 185 * t)
    signal = (noise * 0.62 + tone * 0.38) * np.exp(-t * 17.0) * amp
    mix[left:left + size, 0] += signal * 0.88
    mix[left:left + size, 1] += signal


def add_hat(mix: np.ndarray, start: float, amp: float = 0.025, pan: float = 0.0) -> None:
    left = int(start * SR)
    size = min(int(0.085 * SR), mix.shape[0] - left)
    if size <= 0:
        return
    t = np.arange(size, dtype=np.float32) / SR
    noise = RNG.normal(0, 1, size).astype(np.float32)
    noise -= np.convolve(noise, np.ones(13, dtype=np.float32) / 13.0, mode="same")
    noise *= np.exp(-t * 49.0) * amp
    angle = (pan + 1.0) * np.pi / 4.0
    mix[left:left + size, 0] += noise * np.cos(angle)
    mix[left:left + size, 1] += noise * np.sin(angle)


def add_riser(mix: np.ndarray, start: float, duration: float, amp: float = 0.09) -> None:
    left = int(start * SR)
    size = min(int(duration * SR), mix.shape[0] - left)
    if size <= 0:
        return
    noise = RNG.normal(0, 1, size).astype(np.float32)
    noise = np.convolve(noise, np.ones(27, dtype=np.float32) / 27.0, mode="same")
    rise = np.linspace(0.0, 1.0, size, dtype=np.float32) ** 2.2
    shimmer = 0.58 + 0.42 * np.sin(np.linspace(0, 34 * np.pi, size, dtype=np.float32))
    signal = noise * rise * shimmer * amp
    mix[left:left + size, 0] += signal * np.linspace(1.0, 0.55, size)
    mix[left:left + size, 1] += signal * np.linspace(0.55, 1.0, size)


def build_soundtrack() -> None:
    """A dynamic 126-second original score: piano, guitar, strings, bass and pop drums."""
    bpm = 84.0
    beat = 60.0 / bpm
    bars = 44
    duration = bars * 4 * beat
    mix = np.zeros((int((duration + 1.5) * SR), 2), dtype=np.float32)

    # Original A-major/F#-minor colour palette. Each item is bass + upper chord tones.
    harmony = [
        (45, [57, 61, 64, 71]),
        (44, [56, 59, 64, 69]),
        (42, [54, 57, 61, 64]),
        (38, [50, 54, 57, 64]),
        (47, [59, 62, 66, 69]),
        (40, [52, 56, 59, 66]),
        (42, [54, 57, 61, 69]),
        (38, [50, 54, 57, 61]),
    ]
    melody = [
        76, 78, 81, 80, 76, 73, 76, 78,
        83, 81, 78, 76, 73, 71, 73, 76,
        78, 81, 85, 83, 81, 78, 76, 73,
        71, 73, 76, 80, 78, 76, 73, 71,
    ]
    arp_pattern = [0, 2, 1, 3, 0, 2, 1, 3]

    for bar in range(bars):
        start = bar * 4 * beat
        bass, tones = harmony[bar % len(harmony)]
        intro = bar < 4
        verse = 4 <= bar < 12
        lift = 12 <= bar < 20
        chorus = 20 <= bar < 28 or 32 <= bar < 41
        breath = 28 <= bar < 32
        outro = bar >= 41
        energy = 0.48 if intro else 0.68 if verse else 0.84 if lift else 1.0 if chorus else 0.56 if breath else 0.78

        # Wide sustained strings/pad: the emotional bed, with octave lift in choruses.
        if bar >= 2:
            pans = (-0.72, -0.2, 0.28, 0.72)
            for index, note in enumerate(tones):
                add_note(mix, start, 4.22 * beat, note, 0.036 * energy, pans[index], "string", 0.42, 0.82)
                if chorus and index in (0, 2):
                    add_note(mix, start + 0.04, 4.12 * beat, note + 12, 0.018 * energy, -pans[index], "string", 0.58, 0.9)

        # Close, percussive piano arpeggio. It remains audible even under the chorus drums.
        for step, tone_index in enumerate(arp_pattern):
            note = tones[tone_index] + (12 if step in (1, 3, 5, 7) else 0)
            accent = 1.18 if step in (0, 4) else 0.82
            add_note(mix, start + step * beat / 2, beat * (0.74 if chorus else 0.92), note,
                     0.105 * energy * accent, -0.30 + tone_index * 0.18, "warm", 0.006, 0.25)

        # Acoustic strums spread across the stereo field.
        if bar >= 4 and not breath:
            pulses = (0.0, 1.5, 2.0, 3.5) if not chorus else (0.0, 0.75, 1.5, 2.0, 2.75, 3.5)
            for pulse in pulses:
                for index, note in enumerate(tones[:3]):
                    add_note(mix, start + (pulse + index * 0.025) * beat, 0.72 * beat, note + 12,
                             0.038 * energy, 0.25 + index * 0.22, "guitar", 0.004, 0.34)

        # Warm sub/bass motion.
        if bar >= 4:
            bass_pulses = (0.0, 1.5, 2.0, 3.25) if chorus else (0.0, 2.0)
            for pulse in bass_pulses:
                add_note(mix, start + pulse * beat, 0.82 * beat, bass, 0.13 * energy, -0.03, "sine", 0.018, 0.20)

        # Entirely original lead theme; doubles with strings for the two big lifts.
        if 6 <= bar < 43 and not breath:
            lead_index = (bar * 2) % len(melody)
            first = melody[lead_index]
            second = melody[(lead_index + 1) % len(melody)]
            lead_amp = 0.083 if chorus else 0.057
            add_note(mix, start + 0.45 * beat, 1.28 * beat, first, lead_amp * energy, -0.12, "bell", 0.007, 0.52)
            add_note(mix, start + 2.45 * beat, 1.32 * beat, second, lead_amp * energy, 0.16, "bell", 0.007, 0.56)
            if chorus:
                add_note(mix, start + 0.48 * beat, 1.58 * beat, first - 12, 0.038, 0.58, "string", 0.16, 0.65)
                add_note(mix, start + 2.48 * beat, 1.52 * beat, second - 12, 0.034, -0.52, "string", 0.16, 0.65)

        # Pop-cinematic drums. They intentionally enter late so the first lift has impact.
        if lift or chorus or outro:
            kick_pulses = (0.0, 2.0) if lift or outro else (0.0, 1.5, 2.0, 3.25)
            for pulse in kick_pulses:
                add_kick(mix, start + pulse * beat, 0.25 if chorus else 0.18)
            for pulse in (1.0, 3.0):
                add_snare(mix, start + pulse * beat, 0.13 if chorus else 0.085)
            divisions = 16 if chorus else 8
            for step in range(divisions):
                add_hat(mix, start + step * 4 * beat / divisions, 0.029 if chorus else 0.018,
                        -0.55 if step % 2 else 0.55)

        # Tiny heartbeat in the quiet middle section.
        if breath:
            for pulse in (0.0, 0.36, 2.0, 2.36):
                add_pitch_sweep(mix, start + pulse * beat, 0.20, 74, 45, 0.075, 0.0, 0.12)

        # Section launches: noise rise plus a bright impact chord.
        if bar in (19, 31):
            add_riser(mix, start, 4 * beat, 0.12)
        if bar in (20, 32, 40):
            add_noise_hit(mix, start, 1.35, 0.16, -0.25)
            add_note(mix, start, 2.3 * beat, tones[0] + 24, 0.08, 0.35, "bell", 0.004, 1.0)

    mastered = soften_and_master(mix, reverb=True)
    # A second gentle drive raises perceived loudness without digital clipping.
    mastered = np.tanh(mastered * 1.42)
    mastered /= float(np.max(np.abs(mastered))) or 1.0
    mastered *= 0.965
    fade_in = int(1.55 * SR)
    fade_out = int(4.8 * SR)
    mastered[:fade_in] *= np.linspace(0, 1, fade_in, dtype=np.float32)[:, None] ** 1.1
    mastered[-fade_out:] *= np.linspace(1, 0, fade_out, dtype=np.float32)[:, None] ** 1.35
    export_mp3("moonlit-us.mp3", mastered.astype(np.float32), "320k")


def blank(seconds: float) -> np.ndarray:
    return np.zeros((int(seconds * SR), 2), dtype=np.float32)


def stereo_note(seconds: float, notes: list[tuple[float, float, float, str, float]]) -> np.ndarray:
    mix = blank(seconds)
    for start, duration, note, kind, amp in notes:
        add_note(mix, start, duration, note, amp, RNG.uniform(-0.22, 0.22), kind, 0.005, min(0.34, duration * 0.55))
    return soften_and_master(mix, reverb=True)


def noise_sweep(seconds: float, *, reverse: bool = False, grit: float = 0.34) -> np.ndarray:
    mix = blank(seconds)
    size = mix.shape[0]
    noise = RNG.normal(0, 1, size).astype(np.float32)
    smooth = np.convolve(noise, np.ones(19, dtype=np.float32) / 19.0, mode="same")
    shape = np.clip(np.sin(np.linspace(0, np.pi, size, dtype=np.float32)), 0.0, 1.0) ** 1.45
    direction = np.linspace(0.28, 1.0, size, dtype=np.float32)
    if reverse:
        direction = direction[::-1]
    signal = smooth * shape * direction * grit
    mix[:, 0] = signal * np.linspace(1.0, 0.62, size)
    mix[:, 1] = signal[::-1] * np.linspace(0.62, 1.0, size)
    return mix


def instant_transient(seconds: float = 0.14, amp: float = 0.22, pan: float = 0.0) -> np.ndarray:
    """A context-layer attack with no silent ramp, so touch feedback is audible immediately."""
    mix = blank(seconds)
    add_noise_hit(mix, 0.0, min(0.095, seconds), amp, pan)
    return mix


def mix_layers(*layers: np.ndarray, reverb: bool = True) -> np.ndarray:
    size = max(layer.shape[0] for layer in layers)
    mix = np.zeros((size, 2), dtype=np.float32)
    for layer in layers:
        mix[:layer.shape[0]] += layer
    return soften_and_master(mix, reverb=reverb)


def sweep_effect(seconds: float, sweeps: list[tuple[float, float, float, float, float, float]]) -> np.ndarray:
    mix = blank(seconds)
    for start, duration, first, last, amp, pan in sweeps:
        add_pitch_sweep(mix, start, duration, first, last, amp, pan)
    return mix


def build_sfx() -> None:
    effects: dict[str, np.ndarray] = {}

    effects["tap.mp3"] = mix_layers(
        stereo_note(.24, [(0, .13, 88, "bell", .38), (.045, .17, 95, "bell", .21)]),
        noise_sweep(.18, reverse=True, grit=.08), reverb=False,
    )
    effects["pop.mp3"] = mix_layers(
        sweep_effect(.42, [(0, .22, 210, 72, .42, 0), (.08, .28, 420, 880, .15, .28)]),
        noise_sweep(.24, reverse=True, grit=.12), instant_transient(.11, .20), reverb=False,
    )
    effects["sparkle.mp3"] = stereo_note(1.15, [
        (0, .56, 79, "bell", .29), (.10, .62, 83, "bell", .27), (.22, .68, 88, "bell", .25),
        (.37, .68, 91, "bell", .21), (.55, .55, 95, "bell", .16),
    ])
    effects["correct.mp3"] = stereo_note(1.42, [
        (0, .82, 69, "warm", .34), (.08, .86, 73, "guitar", .29), (.17, .91, 76, "warm", .30),
        (.36, .92, 81, "bell", .26), (.58, .73, 85, "bell", .19),
    ])
    effects["wrong.mp3"] = mix_layers(
        sweep_effect(.58, [(0, .28, 240, 92, .38, -.15), (.21, .31, 170, 68, .34, .15)]),
        noise_sweep(.31, reverse=True, grit=.10), instant_transient(.10, .13), reverb=False,
    )
    effects["kiss.mp3"] = mix_layers(
        noise_sweep(.62, reverse=False, grit=.13),
        sweep_effect(.75, [(.04, .25, 160, 320, .22, -.12), (.21, .48, 520, 1080, .23, .2)]),
        instant_transient(.08, .10),
    )
    effects["piano.mp3"] = stereo_note(1.55, [
        (0, 1.25, 69, "warm", .36), (.08, 1.28, 73, "warm", .31), (.16, 1.24, 76, "warm", .28),
        (.29, 1.10, 81, "bell", .17),
    ])
    effects["guitar.mp3"] = stereo_note(1.28, [
        (0, 1.05, 57, "guitar", .36), (.028, 1.02, 64, "guitar", .31), (.058, .98, 69, "guitar", .29),
        (.09, .93, 73, "guitar", .22),
    ])
    effects["heartbeat.mp3"] = sweep_effect(.82, [
        (0, .24, 76, 43, .48, 0), (.31, .29, 70, 39, .40, 0),
    ])
    effects["heartbeat.mp3"] = mix_layers(effects["heartbeat.mp3"], instant_transient(.08, .10), reverb=False)
    effects["cup.mp3"] = mix_layers(
        stereo_note(.94, [(0, .43, 91, "bell", .31), (.07, .58, 98, "bell", .22), (.23, .64, 86, "bell", .18)]),
        noise_sweep(.18, reverse=True, grit=.05),
    )

    drum_mix = blank(.58)
    add_kick(drum_mix, 0, .47)
    add_snare(drum_mix, .18, .19)
    effects["drum.mp3"] = soften_and_master(drum_mix, reverb=False)

    camera_mix = blank(.58)
    add_noise_hit(camera_mix, 0, .11, .48, -.12)
    add_noise_hit(camera_mix, .12, .16, .31, .12)
    add_note(camera_mix, .08, .38, 91, .22, .2, "bell", .002, .18)
    effects["camera.mp3"] = soften_and_master(camera_mix, reverb=False)

    effects["chime.mp3"] = stereo_note(1.72, [
        (0, 1.06, 76, "bell", .30), (.16, 1.16, 81, "bell", .28), (.36, 1.21, 85, "bell", .23),
        (.62, .98, 92, "bell", .18),
    ])
    effects["finale.mp3"] = mix_layers(
        stereo_note(4.60, [
            (0, 3.8, 57, "string", .28), (.04, 3.75, 64, "string", .24), (.10, 3.70, 69, "string", .25),
            (.18, 3.55, 73, "string", .22), (.43, 2.40, 76, "bell", .23), (.92, 2.65, 81, "bell", .22),
            (1.42, 2.70, 85, "bell", .18), (2.05, 2.30, 88, "bell", .15),
        ]),
        noise_sweep(3.1, reverse=False, grit=.11),
    )

    effects["page-whoosh.mp3"] = mix_layers(
        noise_sweep(1.02, reverse=False, grit=.39),
        sweep_effect(1.02, [(.06, .76, 85, 680, .18, -.4), (.24, .66, 130, 920, .14, .45)]),
        instant_transient(.09, .11, -.25),
        reverb=False,
    )
    effects["car.mp3"] = mix_layers(
        sweep_effect(1.46, [(0, 1.30, 48, 132, .39, 0), (.19, 1.10, 92, 260, .21, -.18)]),
        noise_sweep(1.25, reverse=False, grit=.16), instant_transient(.13, .20), reverb=False,
    )
    effects["belan.mp3"] = mix_layers(
        sweep_effect(.62, [(0, .18, 160, 70, .54, 0), (.05, .34, 480, 125, .22, -.2)]),
        noise_sweep(.34, reverse=True, grit=.30), instant_transient(.12, .38), reverb=False,
    )
    effects["whoosh-hit.mp3"] = mix_layers(
        noise_sweep(.57, reverse=False, grit=.35),
        sweep_effect(.62, [(.06, .44, 120, 720, .16, .25)]),
        instant_transient(.085, .14, .2), reverb=False,
    )
    effects["tetris.mp3"] = mix_layers(
        sweep_effect(.42, [(0, .19, 310, 185, .32, -.15), (.10, .25, 620, 330, .24, .2)]),
        noise_sweep(.20, reverse=True, grit=.08), instant_transient(.08, .15), reverb=False,
    )
    effects["drop.mp3"] = mix_layers(
        sweep_effect(.72, [(0, .28, 390, 82, .39, 0), (.23, .42, 220, 660, .22, .2)]),
        noise_sweep(.31, reverse=True, grit=.18), instant_transient(.11, .24), reverb=False,
    )
    effects["bow.mp3"] = mix_layers(
        noise_sweep(.82, reverse=False, grit=.18),
        sweep_effect(.88, [(0, .45, 105, 245, .18, -.4), (.29, .48, 260, 1180, .25, .45)]),
        instant_transient(.09, .12, -.2), reverb=False,
    )
    effects["balloon.mp3"] = mix_layers(
        noise_sweep(.39, reverse=True, grit=.45),
        sweep_effect(.48, [(0, .22, 290, 76, .41, 0), (.08, .31, 740, 1200, .17, .28)]),
        instant_transient(.095, .42), reverb=False,
    )
    effects["gift.mp3"] = stereo_note(1.38, [
        (0, .68, 76, "bell", .32), (.13, .77, 81, "bell", .28), (.31, .88, 85, "bell", .25),
        (.52, .78, 90, "bell", .18),
    ])
    effects["sleep-chime.mp3"] = stereo_note(2.05, [
        (0, 1.55, 69, "bell", .23), (.28, 1.55, 76, "bell", .22), (.61, 1.32, 81, "bell", .19),
        (.94, 1.01, 88, "bell", .13),
    ])

    for name, audio in effects.items():
        export_mp3(name, audio, "256k")


if __name__ == "__main__":
    build_soundtrack()
    build_sfx()
    print(f"Generated {len(list(OUT.glob('*.mp3')))} V10 MP3 assets in {OUT}")

#!/usr/bin/env python3
"""Static, behavioral, media and routing integrity audit for the complete V10 package."""

from __future__ import annotations

import json
import math
import re
import subprocess
from array import array
from pathlib import Path
from urllib.parse import urlparse

from lxml import html
from PIL import Image


ROOT = Path(__file__).resolve().parent
HTML = (ROOT / "index.html").read_text(encoding="utf-8")
JS = (ROOT / "app.js").read_text(encoding="utf-8")
CSS = (ROOT / "styles.css").read_text(encoding="utf-8")
SW = (ROOT / "sw.js").read_text(encoding="utf-8")
DOC = html.fromstring(HTML)
CHECKS: list[str] = []


def check(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)
    CHECKS.append(message)


def probe_audio(path: Path) -> dict[str, str]:
    process = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration,bit_rate,size", "-of", "json", str(path)],
        check=True,
        capture_output=True,
        text=True,
    )
    return json.loads(process.stdout)["format"]


def opening_rms_db(path: Path, seconds: float = 0.04) -> float:
    """Measure what a person hears immediately, not merely when play() resolves."""
    process = subprocess.run(
        [
            "ffmpeg", "-hide_banner", "-loglevel", "error", "-i", str(path),
            "-t", str(seconds), "-f", "f32le", "-ac", "1", "-ar", "44100", "pipe:1",
        ],
        check=True,
        capture_output=True,
    )
    samples = array("f")
    samples.frombytes(process.stdout)
    if not samples:
        return -120.0
    rms = math.sqrt(sum(sample * sample for sample in samples) / len(samples))
    return 20.0 * math.log10(max(rms, 1e-9))


ids = DOC.xpath("//*[@id]/@id")
check(len(ids) == len(set(ids)), "HTML IDs are unique")

js_ids = set(re.findall(r'\$\("#([A-Za-z][\w-]*)"\)', JS))
missing_ids = sorted(js_ids - set(ids))
check(not missing_ids, f"all {len(js_ids)} direct JavaScript ID references exist")

scenes = DOC.xpath('//*[@data-scene]/@data-scene')
check(len(scenes) == 18, "18 story scenes are present")
match = re.search(r'const sceneOrder = \[([^;]+)\];', JS)
scene_order = re.findall(r'"([^"]+)"', match.group(1)) if match else []
check(scene_order == scenes, "scene routing order exactly matches the DOM")
go_targets = DOC.xpath('//*[@data-go]/@data-go')
check(not (set(go_targets) - set(scenes)), "every CTA routes to a real scene")
check(all(f'"{name}"' in JS for name in scenes), "every scene is represented in app logic")

check(len(DOC.xpath('//*[@data-photo-memory]')) == 3, "first-photo prologue has 3 playable memory hotspots")
check('id="photo-focus"' in HTML and "photoFocused" in JS, "first-photo focus slider unlock is wired")
for relative, minimum in [
    ("assets/images/our-first-photo.jpg", (1400, 900)),
    ("assets/images/sleep-gaze-reference.jpg", (1100, 1400)),
]:
    with Image.open(ROOT / relative) as image:
        check(image.width >= minimum[0] and image.height >= minimum[1], f"story image is high resolution: {relative}")

check(len(DOC.xpath('//*[@data-memory]')) == 4 and "memoryLines" in JS, "Panda memory hunt has 4 clues")
check(len(DOC.xpath('//*[@data-decoder]')) == 3 and "decoderCases" in JS, "language decoder is interactive")
check("Bapch*da" in HTML and "Bapch*da" in JS, "requested humorous scolding appears in gameplay")
check(len(DOC.xpath('//*[@data-lane]')) == 3 and "state.belanDodges >= 5" in JS, "Belan dodge game requires 5 saves")
check('id="belan-start"' in HTML and 'prepareBelanGame()' in JS, "Belan game waits behind an explicit start control")
check("belanMovedThisRound && belanLane !== duduLane" in JS, "Belan success requires an actual safe-lane move each round")
check(JS.count("function startBelanGame()") == 1 and JS.count("state.belanDodges += 1") == 1, "Belan cannot auto-start or auto-award a dodge")
check('id="belan-countdown"' in HTML and 'scheduleBelan(1480)' in JS, "Belan start has a visible readiness countdown")


def simulated_dodge(origin: int, taps: list[int], falling_lane: int) -> bool:
    final_lane = taps[-1] if taps else origin
    moved = any(lane != origin for lane in taps)
    return moved and falling_lane != final_lane


check(not simulated_dodge(1, [], 0), "Belan simulation: standing still never scores")
check(not simulated_dodge(1, [0], 0), "Belan simulation: moving into the hit lane never scores")
check(simulated_dodge(1, [2], 0), "Belan simulation: an actual safe-lane move scores exactly once")
check(len(DOC.xpath('//*[@data-mood]')) == 4, "date-vibe laboratory has 4 choices")
check("spawnSnack" in JS and "state.snacks >= 6" in JS, "falling-snack game requires 6 catches")
check(len(DOC.xpath('//*[@data-pad]')) == 4 and "rhythmPattern" in JS, "Jaguar rhythm game is wired")
check('options: ["Good food", "Nainsi ki Aawaaz", "Obviously both"], correct: 1' in JS, "Nainsi ki Aawaaz is the first quiz answer")
check(len(DOC.xpath('//*[@data-answer]')) == 3 and "quizQuestions" in JS, "relationship quiz is wired")
check(len(DOC.xpath('//*[@data-status-bg]')) == 3 and len(DOC.xpath('//*[@data-status-line]')) == 3, "status creator controls are wired")
check('id="tetris-board"' in HTML and all(f'id="tetris-{name}"' in HTML for name in ["left", "right", "rotate", "drop"]), "Love Tetris has four play controls")
check("state.tetrisLines += 1" in JS and "state.tetrisLines < 3" in JS, "Love Tetris requires 3 completed lines")
check(len(DOC.xpath('//*[@data-balloon]')) == 4 and 'id="bow-control"' in HTML, "bow-and-balloon game has 4 gift targets")
check("setPointerCapture" in JS and "shootBalloon" in JS, "bow supports real pull-and-release gestures")
check("Math.hypot" in JS and 'document.addEventListener("pointerup", release' in JS, "bow release survives a finger leaving the button")
check(".balloon-sky,.balloon-sky*{touch-action:none!important}" in CSS.replace(" ", "") and "held / 6.2" in JS, "entire mobile bow arena blocks page scroll and supports hold-to-charge")
check("bow-dragging" in JS and 'id="bow-charge-fill"' in HTML and 'id="bow-charge-label"' in HTML, "bow exposes visible charge and gesture-lock feedback")
check("resetBowInteraction(true)" in JS and "bowFlightAnimation" in JS, "bow gesture and flight clean up when its scene exits")
check(len(DOC.xpath('//*[@data-dream]')) == 4 and "dreamLines" in JS, "animated sleep-gaze chapter has 4 discoveries")
check("duration = 1200" in JS and "holdFallbackTaps < 3" in JS, "long-press game has a 3-tap fallback")
check("state.kisses >= 5" in JS and "Math.max(360, 570 - state.kisses * 38)" in JS, "moving kiss requires 5 catches")
check(len(DOC.xpath('//*[@data-star]')) == 5, "promise constellation has 5 stars")
check("proposalRuns < 5" in JS and "acceptProposal();" in JS, "proposal runs 5 times and accepts on click 6")
check("walkout-duo" in HTML and "🐼" in HTML and "🧸" in HTML and "🤝" in HTML, "Panda and Teddy hold hands for the walkout")
check("contain:paint" in CSS.replace(" ", "") and "walk-to-portal" in CSS and "translateX(31vw)" in CSS, "final walkout stays clipped inside its portal")

whatsapp = "https://wa.me/+917004804153"
check(HTML.count(whatsapp) >= 2 and whatsapp in JS, "all final WhatsApp actions use the requested number")

check(all(item in HTML for item in ['id="immersive-gate"', 'id="music-check"', 'id="fullscreen-check"', 'id="haptic-check"']), "opening gate shows music, fullscreen and haptic status")
check("fullscreenReady && musicReady" in JS, "gate unlocks only after music and fullscreen succeed")
check("requestFullscreen" in JS and "this.music.play()" in JS, "fullscreen and audio start from the opening gesture")
check('document.addEventListener("pointerdown", press' in JS, "feedback begins on pointerdown for gesture-safe Android haptics")
check("AudioContext" in JS and "createBufferSource" in JS and "preloadBuffers" in JS, "interaction MP3s use predecoded low-latency Web Audio buffers")
check('latencyHint: "interactive"' in JS and "this.bufferPromise" in JS, "opening gate primes low-latency audio before gameplay")
check("navigator.vibrate(pattern)" in JS and "navigator.vibrate(0)" not in JS, "haptics use a direct Android vibration command")
check('document.addEventListener("touchstart", press' in JS and "now - lastAt < 45" in JS, "haptics include a deduplicated Android touch fallback")
pattern_block = re.search(r'this\.patterns = \{(.+?)\};', JS, re.S)
durations = [int(value) for value in re.findall(r'(?<![.\w])(\d{2,3})(?![.\w])', pattern_block.group(1) if pattern_block else "")]
check(durations and max(durations) >= 200 and min(durations) >= 28, "haptic patterns are long enough for common Android motors")
check("music picker" not in HTML.lower() and 'type="file"' not in HTML.lower(), "there is no music chooser interrupting the flow")
check(all(f'id="{game}-start"' in HTML for game in ["belan", "snack", "tetris", "kiss"]), "all time-pressure games have explicit start controls")
check(all(f'prepare{name}Game()' in JS for name in ["Belan", "Snack", "Tetris", "Kiss"]), "timed games never auto-start while copy is being read")
check("state.moods.length < 2" in JS, "two requested date vibes are required before advancing")
mode_match = re.search(r'const sceneModes = \{(.+?)\};', JS, re.S)
mode_keys = re.findall(r'\b([a-z]+):\s*"', mode_match.group(1) if mode_match else "")
check(mode_keys == scenes, "MECE interaction-mode map covers every scene exactly once")
check("enterSceneMechanic(name)" in JS and "exitSceneMechanic(currentScene)" in JS, "MECE scene lifecycle owns all live-game entry and cleanup")

manifest = json.loads((ROOT / "manifest.webmanifest").read_text(encoding="utf-8"))
check(manifest.get("display") == "fullscreen", "PWA manifest requests fullscreen display")
check(manifest.get("start_url") == "./#home", "PWA start URL uses stable hash routing")
check("location.hash" in JS and "history.pushState" in JS, "chapters use reload-safe hash routing")
check((ROOT / "404.html").exists() and (ROOT / ".nojekyll").exists(), "GitHub Pages reload fallbacks are present")
check((ROOT / ".github/workflows/deploy-pages.yml").exists(), "GitHub Pages deployment workflow is included")
workflow = (ROOT / ".github/workflows/deploy-pages.yml").read_text(encoding="utf-8")
check("Piyush-Nainsi-Afterhours-V*.zip" in workflow and "path: _site" in workflow, "workflow can deploy future updates from one uploaded ZIP")
check("serviceWorker.register" in JS and (ROOT / "sw.js").exists(), "offline service worker is registered on HTTPS")
check('afterhours-v10.0.0' in SW and 'afterhours-v9' not in SW and 'afterhours-v8' not in SW, "service-worker cache is versioned for V10")

local_assets: set[str] = set()
for element in DOC.xpath('//*[@src or @href]'):
    value = element.get("src") or element.get("href") or ""
    parsed = urlparse(value)
    if parsed.scheme or value.startswith("#") or value.startswith("data:"):
        continue
    local = value.split("?", 1)[0].split("#", 1)[0]
    if local:
        local_assets.add(local)
        check((ROOT / local).exists(), f"local asset exists: {local}")
check(all(f'"./{asset}"' in SW for asset in local_assets if not asset.endswith("404.html")), "service worker pre-caches all HTML-linked local assets")

check(CSS.count("{") == CSS.count("}"), "CSS braces are balanced")
check("@font-face" in CSS and len(list((ROOT / "assets/fonts").glob("*.woff"))) == 3, "three offline cute-font fallbacks are bundled")
check("prefers-reduced-motion" in CSS, "reduced-motion accessibility is covered")
check("overflow-x:hidden" in CSS.replace(" ", ""), "mobile document prevents horizontal overshoot")
check("pointer-events:none" in CSS.replace(" ", ""), "decorative overlays cannot steal taps")

audio_files = sorted((ROOT / "assets/audio").glob("*.mp3"))
check(len(audio_files) == 25, "25 bundled MP3 assets are present")
for audio in audio_files:
    metadata = probe_audio(audio)
    check(float(metadata["duration"]) > 0.20, f"audio decodes: {audio.name}")
    minimum_bitrate = 300_000 if audio.name == "moonlit-us.mp3" else 240_000
    check(int(metadata["bit_rate"]) >= minimum_bitrate, f"audio bitrate is high quality: {audio.name}")

effects = [path for path in audio_files if path.name != "moonlit-us.mp3"]
opening_levels = [opening_rms_db(path) for path in effects]
check(max(opening_levels) < 0 and min(opening_levels) > -34, "every interaction MP3 has an audible attack inside the first 40 ms")

music = probe_audio(ROOT / "assets/audio/moonlit-us.mp3")
check(float(music["duration"]) > 125, "background score is longer than 125 seconds")
check(int(music["bit_rate"]) >= 300_000, "background score is at least 300 kbps")
check(int(music["size"]) > 4_500_000, "background score contains the full high-impact arrangement")

subprocess.run(["node", "--check", str(ROOT / "app.js")], check=True, capture_output=True, text=True)
check(True, "JavaScript passes Node syntax validation")
check("V9" not in HTML and "afterhours-v9" not in JS + CSS + SW, "no stale V9 runtime identifiers remain")

print(f"V10 audit passed: {len(CHECKS)} checks")
for item in CHECKS:
    print(f"  ✓ {item}")
